<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-US">

<head>
	<style type="text/css" media="screen">
		@import url(style.css);
	</style>
<?php session_start(); ?>
</head>

<body>

<div id="page_container" class="aligncenter">
<div id="top_row">
  <div id='head_row_one'>
    <?php 
if(isset($_COOKIE['userEpub']['un']) && isset($_COOKIE['userEpub']['status']) && isset($_COOKIE['userEpub']['priv']) ){


if($_COOKIE['userEpub']['status'] == 'logged'){	 ?>
<div class="opsPanel">
  <ul>
    <li>
<?PHP
if($_COOKIE['userEpub']['priv'] == 'admin'){?>
<a href="admin_tools/cp.php">
<?PHP }else{ ?>
    <a href="user_tools/cp.php">
<?PHP } ?>
        <img src="images/cp_icon.gif"/>
      </a>
    </li>
    <li>
      <a href="shop/viewCart.php">
        <img src="images/cart.gif"/>
      </a>
    </li>
  </ul>
  
</div>
    <div class="right" width="218">
  <div class="right" width="218">

    <div class="row">
      Welcome &nbsp; <?PHP echo $_COOKIE['userEpub']['un'].'.'; ?>
    </div>
    <div class="row">
      You are logged in.
    </div>
    <div class="row">
      <a href="login_tools/log_tool.php?action=logout">Logout
      
      </a>
    </div>
  </div>
    </div>
      <?PHP }
elseif($_COOKIE['userEpub']['status'] == 'notlogged'){ ?>
      <div class="row right" width="218">
        <form id="login_form" name="login_form" action="login_tools/log_tool.php?action=login" method="post">
          User Login

          <input size="15" name="user_name" id="user_name" class="search_fields" />

          <input size="15" type="password" name="password" id="password"  class="search_fields" />

          <a href="login_tools/register.php">Register</a>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <input name="submit" type="submit" value="Login" style="border:1px solid #999999; background-color:#CCCCCC; font-size:10px"/>

        </form>
      </div>
      <?PHP
}
}
else{
$_COOKIE['userEpub']['un']= 'guest'; 
$_COOKIE['userEpub']['status']= 'notlogged'; 
$_COOKIE['userEpub']['priv']= 'guest';?>
      <div class="right" width="218">
        <form id="login_form" name="login_form" action="login_tools/log_tool.php?action=login" method="post">
          User Login
          <input size="15" name="user_name" id="user_name" class="search_fields" />

          <input size="15" type="password" name="password" id="password"  class="search_fields" />

          <a href="login_tools/register.php" >Register</a>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <input name="submit" type="submit" value="Login" style="border:1px solid #999999; background-color:#CCCCCC; font-size:10px"/>

        </form>
      </div>
      <?PHP

}
?>
    </div>

    <div id="clear_both" style="clear:both;"></div>

<div id="menu" class="right">
<ul class="top_nav">
<li><a href="index.php">Home</a></li>
<li><a href="shop/catalog.php">My Shop</a></li>
</ul>

</div>
<div id="clear_both" style="clear:both;"></div>
</div>
<div id="clear_both" style="clear:both;"></div>
<div id="main_row">
<div id="left_container">

</div>
<div id="right_container" style="color:#ffffff;">
<center><h1>Welcome</h1></center>
<center>
<div style="width:50%; text-align:left;">
This is a small application I wrote in our Server Side Class at WITC New Richmond, under the instruction of Diane Pettis.
It has been formatted to work with cookies, the original used session variables, which I like better because it lowers the amount
of data you place on a clients machine that could be used in an unsecure manner.(Though there are other options, where you track your own session)<br/><br/> 

<strong>Due to constraints on this server placed on file and database access SQL INSERTS are
not allowed thus, REGISTRATION, NEW ITEM, PLACE ORDER, will not work. However you should be able to modify existing items via an update if you are logged in under a user with administration privledges. <br/>
FOR USER INFO: contact me Shawn Stark at s.nicholas.mrstark@gmail.com   </strong><br/><br/>

To get started click Shop in the navigation above, you will be able to view and search all items in an access database and
if you are logged in as admin optionaly update the data held in item records by clicking modify to the left of the record. Please take a look at the forms and note the error handling when you add items to cart, view cart, and submit order... <br/><br/>

You can find a zipped version of this application <strong><a href="my_php.zip">HERE</a></strong>,<br/><br/>
<strong>Down Falls and New Project:</strong><br/>
I am working on a project with a user environment and file management system that puts this application to shame
as it is object oriented, non recursive, logs and handles errors from a single point rather than in the function return, uses MYSQL and is neatly wrapped in little packages that should be easier to understand by the programmer than this, it also ensures the program is written in a defined way, along with majority of the classes being portable to JAVA BEANS.  Be on the look out for the zip to appear here as it is DUE next week.
<br/>
<br/>
</div>
</center>
</div>
</div>
<div id="bottom_row">
where ami
</div>

<div id="clear_both" style="clear:both;"></div>
</div>




</body>
</html>