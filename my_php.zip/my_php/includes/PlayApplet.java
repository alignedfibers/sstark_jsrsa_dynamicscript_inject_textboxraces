import java.applet.*;
import java.awt.*;

public class PlayApplet extends Applet 
{
int x =0;
int x2=0;
int x3=0;
int colorSwitch = 1;
int colorSwitch1 = 1;

    public void init()
    {
        setBackground(Color.black);
    }

    public void paint(Graphics g)
    {
        try
        {   
            // Place the full white Moon
            g.setColor(Color.white);                    
            g.fillOval(150,100,70,70);
	    // Place the partial black moon
            g.setColor(Color.blue);
            g.fillOval(130, 85, 70, 70);			  
        
	    for(x=0; x<=450; x++) 
	    {
		switch (colorSwitch) 
		{
		   case 1:
		     g.setColor(Color.blue);
		     colorSwitch = 2;
		     break;
		   case 2:
		     g.setColor(new Color(128,0,128)); 
		     colorSwitch = 3;
		     break;
		   case 3:
		     g.setColor(Color.white); 
		     colorSwitch = 4;
 		     break;
		   case 4:
		     g.setColor(Color.yellow);
		     colorSwitch = 1;
		     
		}
		//Stars 1, 2, 3 
		drawStar(g,440,120,455,135);
		drawStar(g,740,420,755,435);      
		drawStar(g,140,320,155,335);
		
		//Line to test XY coordinates
		g.drawLine(900,0,0,900); 
		g.drawLine(950,0,0,950);
		g.drawLine(0,0,900,900);
		g.drawLine(0,50,900,950);

		//Lowering the Thread # speeds up the Program's loop
		//Rising the Thread # slows down the Programs's loop
		Thread.sleep(2000);
							
             // Move the star
		
		int xx = 900;
		int xxY = 10;
		int xxL = 915;
		int xxH = 25;
		while (xx >= 350) 
		{
		switch (colorSwitch1) 
		{
		   case 1:
		     g.setColor(Color.blue);
		     colorSwitch1 = 2;
		     break;
		   case 2:
		     g.setColor(Color.red); 
		     colorSwitch1 = 3;
		     break;
		   case 3:
		     g.setColor(Color.magenta); 
		     colorSwitch1 = 4;
		     break;
   		   case 4:
		     g.setColor(Color.green); 
		     colorSwitch1 = 5;
		     break;
		   case 5:
		     g.setColor(Color.white); 
		     colorSwitch1 = 1;
		     break;
		} 		
		   drawStar(g,xx,xxY,xxL,xxH);        
            	   Thread.sleep(100);
		   xx = xx - 50;
		   xxY = xxY + 50;
		   xxL = xxL - 50;
		   xxH = xxH + 50;
		g.drawLine(925,0,0,925);
		g.drawLine(0,25,900,925);
		g.drawLine(450,0,450,475);
		g.drawLine(0,475,1500,475);
            	}   
             //End Moving The Star
	    }
        }
           catch (Exception e)
        { 
             System.out.println(e.getMessage());
        }

    }

    void drawStar(Graphics g, int stX, int stY, int stL, int stH) 
    {
	g.drawLine(stX, stY, stL, stH);
	g.drawLine(stX, stY+15, stL, stH-15);
	g.drawLine(stX+8, stY+1, stL-7, stH+1);
	g.drawLine(stX, stY+8, stL, stH-7);
    }

} // PlayApplet
