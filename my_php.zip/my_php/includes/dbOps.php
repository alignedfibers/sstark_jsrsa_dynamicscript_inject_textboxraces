<?PHP
try{
$conn = new COM("ADODB.Connection"); 
$conn->provider = "Microsoft.Jet.OLEDB.4.0";
$conn->open($fileLoc);
}//END TRY
catch(Exception $e)
{
echo $e->getMessage();
}

class dbAdapter{
/******************************************
Trims everything 
but AlphaNumeric charicters and commas
******************************************/
public function trimWithComma($value) 
{ 
    
    $value = preg_replace("/[^a-zA-Z0-9,]/", "", $value); 
    return $value;
}
/********************************************
Trims everything
but AlphaNumeric charicters
********************************************/
public function trimAll($value) 
{ 
    
    $value = preg_replace("/[^a-zA-Z0-9]/", "", $value); 
    return $value;
}
public function updateSubSet($table,$Lbound,$Ubound,$fields,$fldVals){
global $conn;

//$fields = $this->trimWithComma($fields);
$fields = explode(',',$fields);
$fldVals = explode(',',$fldVals);

$sqlStr = 'Update '.$table.' SET ';

foreach($fields As $key=>$value){

$sqlStr = $sqlStr.$value.'= \''.$fldVals[$key].'\', ';
 
}
$sqlStr =  substr_replace($sqlStr,'',-2,2);

$sqlStr = $sqlStr.'WHERE itemID BETWEEN \''.$Lbound.'\' AND \''.$Ubound.'\''; 


try{
$rs = $conn->execute($sqlStr);
return 'true';
}
catch(Exception $e)
{
return 'false';
}

}



public function insertSubSet($table,$fields,$fldVals){
global $conn;

//$fields = $this->trimWithComma($fields);
$fields = explode(',',$fields);
$fldVals = explode(',',$fldVals);

$sqlStr = 'INSERT INTO '.$table.'(';

foreach($fields As $key=>$value){

$sqlStr = $sqlStr.$value.', ';
 
}
$sqlStr =  substr_replace($sqlStr,'',-2,2);

$sqlStr = $sqlStr.') VALUES (';

foreach($fldVals as $key=>$value){
$sqlStr.= '\''.$value.'\',';
}
$sqlStr =  substr_replace($sqlStr,'',-1,1);

$sqlStr.= ' )';
//echo $sqlStr;


try{
$rs = $conn->execute($sqlStr);
return 'true';
}
catch(Exception $e)
{
echo $e->getMessage();
die();
return 'false';
}

}
/**********************************************
This function creates a SELECT statement, executes
it and returns an array of rows. The args passed
to this method are table name, subSet of fields
comma delimited, criteria fields comma delimited,
criteria values comma delimited in the corresponding 
order of criteria fields. This function currently
dose not test to ensure criVals contains the same
number of values as criteria fields. You can
break it
***********************************************/
public function getSubsetByFields($table,$subSet,$criteria,$criVals){
global $conn;
$clock = ''; //I will use start and end time to calc run time
//$subSet = $this->trimWithComma($subSet);
$subSet = explode(',',$subSet);
$criteria = $this->trimWithComma($criteria);
$criteria = explode(',',$criteria);
$criVals = $this->trimWithComma($criVals);
$criVals = explode(',',$criVals);
$sqlStr = 'SELECT ';
foreach($subSet as $key => $value){
$sqlStr.= $value.', ';
}
$sqlStr = substr_replace ($sqlStr, '', -2 , 2);
$sqlStr.= ' FROM '.$table.' WHERE ';
foreach($criteria as $key=>$value){
if($value == 'UserID'){
$sqlStr.= $value.' = '.$criVals[$key].' AND ';
}
else{

$sqlStr.= $value. '= \''.$criVals[$key].'\' AND ';
}
}
$sqlStr = substr_replace ($sqlStr, '', -5 , 5);
//echo $sqlStr;

try{
$rs = $conn->execute($sqlStr);
$resultList = "";
$holdArray = "";

while (!$rs->EOF) {
//echo 'rs loop';
foreach($subSet as $key=>$value){
//if is_null($rs->Fields($value)){}
$holdArray[$value] = (string)$rs->Fields($value);
}
$resultList[] = $holdArray;  

    $rs->MoveNext();    
}
return $resultList;
}
catch(Exception $e)
{
exit('This request can not be processed.<br/>'.$sqlStr.'<br/>'.$e->getMessage());
}
}

/******************************
List All Function PUBLIC
Returns an array of rows
******************************/
public function listAll(){

global $conn;
$rs = $conn->execute('SELECT * FROM Users');
$resultList = "";
$holdArray = "";
while (!$rs->EOF) {
/*
$holdArray['imagePath'] = (string)$rs->Fields('imagePath');
$holdArray['itemID'] = (string)$rs->Fields('itemID');
$holdArray['description'] = (string)$rs->Fields('description');
$holdArray['price'] = '$'.number_format((string)$rs->Fields('price'),2);
*/
$resultList[] = $holdArray;  

    $rs->MoveNext();    



}


return $resultList;
}

/********************************************************
Used in conjunction with parsing strings to create an SQL statement.
returns a string only alphaNumeric with space
********************************************************/
private function trimKeepSpace($value) 
{ 
    $value = preg_replace("/[^a-z \d]/i", "", $value);
    //$value = preg_replace("/[^a-zA-Z0-9s]/", "", $value); 
    return $value;
}
public function search($searchStr){
$sqlStr = "SELECT * FROM Items WHERE";
$searchStr = $this->trimKeepSpace($searchStr);
$searchVals = explode ( ' ', $searchStr );

foreach($searchVals as $key => $value ){
$sqlStr = $sqlStr.' description LIKE \'%'.$value.'%\' OR';
}
$sqlStr = substr_replace ($sqlStr, '', -2 , 2);
global $conn; 
$rs = $conn->execute($sqlStr);
$resultList = "";
$holdArray = "";

while (!$rs->EOF) {

/*$holdArray['imagePath'] = (string)$rs->Fields('imagePath');
$holdArray['itemID'] = (string)$rs->Fields('itemID');
$holdArray['description'] = (string)$rs->Fields('description');
$holdArray['price'] = '$'.number_format((string)$rs->Fields('price'),2);*/
  
$resultList[] = $holdArray;  

    $rs->MoveNext();    



}
return $resultList;
}

}

?>