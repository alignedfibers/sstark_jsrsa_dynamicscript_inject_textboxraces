import java.applet.*;
import java.awt.*;

public class PlayApplet extends Applet 
{

int x =0;
int x2=0;
int x3=0;

    public void init()
    {
        setBackground(Color.black);
    }

    public void paint(Graphics g)
    {

        try
        {

            drawField(g);

            //g.setColor(Color.yellow);
            //Half Moon          
            //g.fillArc(10,10,60,110,120,180);    

            // Place the full white Moon
            g.setColor(Color.white);                    
            g.fillOval(150,100,70,70);
	    // Place the partial black moon
            g.setColor(Color.black);
            g.fillOval(130, 85, 70, 70);
                    
			for(x=0; x<=20; x++) 
			{
		
				g.setColor(Color.blue);
				//Star 1 
				g.drawLine(440,120,455,135);      
				g.drawLine(440,135,455,120);
				g.drawLine(448,121,448,136);
				g.drawLine(440,128,455,128); 

				//Star 2
				g.drawLine(740,420,755,435);      
				g.drawLine(740,435,755,420);
				g.drawLine(748,421,748,436);
				g.drawLine(740,428,755,428); 

				//Star 3
				g.drawLine(140,320,155,335);      
				g.drawLine(140,335,155,320);
				g.drawLine(148,321,148,336);
				g.drawLine(140,328,155,328); 


				Thread.sleep(200);
							
             // Move the star
 
            g.drawLine(900,10,915,25);      
            g.drawLine(900,25,915,10);
            g.drawLine(908,11,908,26);
            g.drawLine(900,18,915,18);
            
            Thread.sleep(200);
                

			g.drawLine(850,60,865,75);      
			g.drawLine(850,75,865,60);
			g.drawLine(858,61,858,76);
			g.drawLine(850,68,865,68);
            
			Thread.sleep(200);
           
           
			g.drawLine(800,110,815,125);      
			g.drawLine(800,125,815,110);
			g.drawLine(808,111,808,126);
			g.drawLine(800,118,815,118);
            
			Thread.sleep(200);

            
			g.drawLine(760,140,775,155);      
			g.drawLine(760,155,775,140);
			g.drawLine(768,141,768,156);
			g.drawLine(760,148,775,148);
            
			Thread.sleep(200);

			g.drawLine(700,170,715,185);      
			g.drawLine(700,185,715,170);
			g.drawLine(708,171,708,186);
			g.drawLine(700,178,715,178);
            
			Thread.sleep(200);

			g.drawLine(650,200,665,215);      
			g.drawLine(650,215,665,200);
			g.drawLine(658,201,658,216);
			g.drawLine(650,208,665,208);
            
			Thread.sleep(200);

			g.drawLine(600,250,615,265);      
			g.drawLine(600,265,615,250);
			g.drawLine(608,251,608,266);
			g.drawLine(600,258,615,258);
            
  
			Thread.sleep(200);

			g.drawLine(550,300,565,315);      
			g.drawLine(550,315,565,300);
			g.drawLine(558,301,558,316);
			g.drawLine(550,308,565,308);
             
			Thread.sleep(200);

			g.drawLine(500,350,515,365);      
			g.drawLine(500,365,515,350);
			g.drawLine(508,351,508,366);
			g.drawLine(500,358,515,358);
            
			Thread.sleep(200);

			g.drawLine(450,400,465,415);      
			g.drawLine(450,415,465,400);
			g.drawLine(458,401,458,416);
			g.drawLine(450,408,465,408);  
             
			Thread.sleep(200);

			g.drawLine(400,450,415,465);      
			g.drawLine(400,465,415,450);
			g.drawLine(408,451,408,466);
			g.drawLine(400,458,415,458);     

            
			Thread.sleep(200);
             

			g.drawLine(350,500,365,515);      
			g.drawLine(350,515,365,500);
			g.drawLine(358,501,358,516);
			g.drawLine(350,508,365,508);          
            
			Thread.sleep(200);


         //End Moving The Start

				//Star 1 
				g.setColor(Color.white);
				g.drawLine(440,120,455,135);      
				g.drawLine(440,135,455,120);
				g.drawLine(448,121,448,136);
				g.drawLine(440,128,455,128);

				//Star 2
				g.drawLine(740,420,755,435);      
				g.drawLine(740,435,755,420);
				g.drawLine(748,421,748,436);
				g.drawLine(740,428,755,428); 

				//Star 3
				g.drawLine(140,320,155,335);      
				g.drawLine(140,335,155,320);
				g.drawLine(148,321,148,336);
				g.drawLine(140,328,155,328); 

				Thread.sleep(500);

				g.setColor(Color.black);
				g.drawLine(900,10,915,25);      
				g.drawLine(900,25,915,10);
				g.drawLine(908,11,908,26);
				g.drawLine(900,18,915,18);
            
				Thread.sleep(200);
                

				g.drawLine(850,60,865,75);      
				g.drawLine(850,75,865,60);
				g.drawLine(858,61,858,76);
				g.drawLine(850,68,865,68);
            
				Thread.sleep(200);
           
           
				g.drawLine(800,110,815,125);      
				g.drawLine(800,125,815,110);
				g.drawLine(808,111,808,126);
				g.drawLine(800,118,815,118);
            
				Thread.sleep(200);

            
				g.drawLine(760,140,775,155);      
				g.drawLine(760,155,775,140);
				g.drawLine(768,141,768,156);
				g.drawLine(760,148,775,148);
            
				Thread.sleep(200);

				g.drawLine(700,170,715,185);      
				g.drawLine(700,185,715,170);
				g.drawLine(708,171,708,186);
				g.drawLine(700,178,715,178);
            
				Thread.sleep(200);

				g.drawLine(650,200,665,215);      
				g.drawLine(650,215,665,200);
				g.drawLine(658,201,658,216);
				g.drawLine(650,208,665,208);
            
				Thread.sleep(200);

				g.drawLine(600,250,615,265);      
				g.drawLine(600,265,615,250);
				g.drawLine(608,251,608,266);
				g.drawLine(600,258,615,258);
            
  
				Thread.sleep(200);

				g.drawLine(550,300,565,315);      
				g.drawLine(550,315,565,300);
				g.drawLine(558,301,558,316);
				g.drawLine(550,308,565,308);
             
				Thread.sleep(200);

				g.drawLine(500,350,515,365);      
				g.drawLine(500,365,515,350);
				g.drawLine(508,351,508,366);
				g.drawLine(500,358,515,358);
            
				Thread.sleep(200);

				g.drawLine(450,400,465,415);      
				g.drawLine(450,415,465,400);
				g.drawLine(458,401,458,416);
				g.drawLine(450,408,465,408);  
             
				Thread.sleep(200);

				g.drawLine(400,450,415,465);      
				g.drawLine(400,465,415,450);
				g.drawLine(408,451,408,466);
				g.drawLine(400,458,415,458);     

            
				Thread.sleep(200);
             

				g.drawLine(350,500,365,515);      
				g.drawLine(350,515,365,500);
				g.drawLine(358,501,358,516);
				g.drawLine(350,508,365,508);          
            
				Thread.sleep(200);



}

         }
         catch (Exception e)
         { 
             System.out.println(e.getMessage());
         }

		


    }

    void drawField(Graphics g)
    {
        
            // Draw the field
            g.setColor(Color.black);
            int[] xPoints = {0,1100,1100,0};
            int[] yPoints = {400,350,800,800};
            int points = 4;
            g.fillPolygon(xPoints, yPoints, points);  

         
              
            

    }



} // PlayApplet
