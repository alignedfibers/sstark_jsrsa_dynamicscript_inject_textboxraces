
<?php
/*function curPageURL() {
  $pageURL = '';
 if ($_SERVER["SERVER_PORT"] != "80") {
  $pageURL .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
 } else {
  $pageURL .= $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
 }
 return $pageURL;
}*/

if(isset($_COOKIE['userEpub']['un']) && isset($_COOKIE['userEpub']['status']) && isset($_COOKIE['userEpub']['priv']) ){

if($_COOKIE['userEpub']['status'] == 'logged'){	 
?>
<div class="opsPanel">
  <ul>
    <li>
<?PHP
if($_COOKIE['userEpub']['priv'] == 'admin'){?>
<a href="../admin_tools/cp.php">
<?PHP }else{ ?>
    <a href="../user_tools/cp.php">
<?PHP } ?>
        <img src="../images/cp_icon.gif"/>
      </a>
    </li>
    <li>
      <a href="../shop/viewCart.php">
        <img src="../images/cart.gif"/>
      </a>
    </li>
  </ul>
  
</div>
<div class="right">

  <div class="right" width="218">

    <div class="row">
      Welcome &nbsp; <?PHP echo $_COOKIE['userEpub']['un'].'.'; ?>
    </div>
    <div class="row">
      You are logged in.
    </div>
    <div class="row">
      <a href="../login_tools/log_tool.php?action=logout">Logout
      
      </a>
    </div>
  </div>

</div>
<?PHP }
elseif($_COOKIE['userEpub']['status'] == 'notlogged'){ ?>
<div class="row right" width="218">
<form id=login_form name=login_form action="../login_tools/log_tool.php?action=login" method="post">
User Login

          <input size="15" name="user_name" id="user_name" class="search_fields" />
          
 <input size="15" type="password" name="password" id="password"  class="search_fields" />
         
                  <a href="../login_tools/register.php">Register</a>
                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <input name="submit" type="submit" value="Login" style="border:1px solid #999999; background-color:#CCCCCC; font-size:10px"/>
          
        </form></div><?PHP
}
}
else{
$_COOKIE['userEpub']['un']= 'guest'; 
$_COOKIE['userEpub']['status']= 'notlogged'; 
$_COOKIE['userEpub']['priv']= 'guest';?>
<div class="right" width="218">
<form id=login_form name=login_form action="../login_tools/log_tool.php?action=login" method="post">
User Login
          <input size="15" name="user_name" id="user_name" class="search_fields" />
          
 <input size="15" type="password" name="password" id="password"  class="search_fields" />
         
                  <a href="../login_tools/register.php" >Register</a>
                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <input name="submit" type="submit" value="Login" style="border:1px solid #999999; background-color:#CCCCCC; font-size:10px"/>
          
        </form></div><?PHP

}
?>