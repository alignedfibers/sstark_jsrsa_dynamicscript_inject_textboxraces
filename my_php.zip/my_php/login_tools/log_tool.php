<?php
include '../includes/conf.php';
include '../includes/dbOps.php';
session_start(); 
$caller = '';
$dataObj = new dbAdapter; 

if(isset($_GET['action'])){

$action = $_GET['action'];
switch($action){

case 'login':
     if(isset($_POST['user_name']) && isset($_POST['password'])){
     $pass = $_POST['password'];
     $user = $_POST['user_name'];
$matchingUsers = $dataObj->getSubsetByFields('Users','UserID,UserName,uPass,Priv','uPass,UserName',$pass.','.$user);
          if ( !is_array($matchingUsers) || empty($matchingUsers) ) { ?>
 <html>
<head>
<meta http-equiv="Refresh" content="5;url=login.php">
</head>
<body>
<div class="row">
<div>Redirecting...<div>
<div>Invalid user name or password</div>
<div>if your browser does not redirect you in 5 seconds click <a href="login.php">here</a></div>
</div>
</body>
</html>
<?PHP }

         elseif ( count($matchingUsers) > 1 ){?>
<html>
<head>
<meta http-equiv="Refresh" content="5;url=../contact/contact.php">
</head>
<body>
<div class="row">
<div>Redirecting...<div>
<div>Database Integrity Problem contact administrator</div>
<div>if your browser does not redirect you in 5 seconds click <a href="../contact/contact.php">here</a></div>
</div>
</body>
</html>
<?PHP }
else{
$id = "id";
$un = "un";
$priv = "priv";
$status = "status";

setcookie("userEpub[$id]",$matchingUsers[0]['UserID'],time()+3600*24,"/");
setcookie("userEpub[$un]",$matchingUsers[0]['UserName'],time()+3600*24,"/") ;
setcookie("userEpub[$priv]",$matchingUsers[0]['Priv'],time()+3600*24,"/");
setcookie("userEpub[$status]" ,"logged",time()+3600*24,"/");
?>
<html>
<head>
<meta http-equiv="Refresh" content="5;url=../index.php">
</head>
<body>
<div class="row">
<div>Redirecting...<div>
<div>You are logged in</div>
<div>if your browser does not redirect you in 5 seconds click <a href="../index.php">here</a></div>
</div>
</body>
</html>
<?PHP
      }
}
else{?>
<html>
<head>
<meta http-equiv="Refresh" content="5;url=../index.php">
</head>
<body>
<div class="row">
<div>Redirecting to login...<div>
<div>User name and Password Not supplied</div>
<div>if your browser does not redirect you in 5 seconds click <a href="login.php">here</a></div>
</div>
</body>
</html>
<?PHP }

break;
case 'reg':
     if(isset($_POST['un']) && isset($_POST['pass'])&& isset($_POST['fname'])&& isset($_POST['lname'])&& isset($_POST['addrs'])&& isset($_POST['city'])&& isset($_POST['stateCmb'])&& isset($_POST['zip'])&& isset($_POST['tPhone'])&& isset($_POST['cPhone'])&& isset($_POST['email'])&& isset($_POST['birthyear'])){

$matchingUsers = $dataObj->getSubsetByFields('Users','UserID,Email','UserName,Email',$_POST['un'].','.$_POST['email']);
          if ( !is_array($matchingUsers) || empty($matchingUsers) ) { 
          $dataObj->insertSubSet('Users','FirstName,LastName,Address,City,State,Zip,Teliphone,Cell,Email,bYear,UserName,Priv,uPass',$_POST['fname'].','.$_POST['lname'].','.$_POST['addrs'].','.$_POST['city'].','.$_POST['stateCmb'].','.$_POST['zip'].','.$_POST['tPhone'].','.$_POST['cPhone'].','.$_POST['email'].','.$_POST['birthyear'].','.$_POST['un'].',user,'.$_POST['pass']);


?>
<html>
  <head>
    <meta http-equiv="Refresh" content="5;url=../login_tools/login.php">
    </head>
  <body>
    <div class="row">
      <div>
        Redirecting...<div>
          <div>You have successfuly registered, you can now log in with the user name and password you provided</div>
          <div>
            if your browser does not redirect you in 5 seconds click <a href="../index.php">here</a>
          </div>
        </div>
      </body>
</html>
<?PHP }else{ ?>
<html>
<head>
<meta http-equiv="Refresh" content="5;url=../login_tools/register.php">
</head>
<body>
<div class="row">
  <div>Redirecting...<div>
<div>Can not process registration the user name or email already exists. Please try registering again</div>
<div>if your browser does not redirect you in 5 seconds click <a href="../login_tools/register.php">here</a></div>
</div>
</body>
</html>
<?PHP }}
else{ ?>
<html>
<head>
<meta http-equiv="Refresh" content="5;url=../login_tools/register.php">
</head>
<body>
<div class="row">
<div>Redirecting...<div>
<div>Can not process registration. Please try registering again</div>
<div>if your browser does not redirect you in 5 seconds click <a href="../login_tools/register.php">here</a></div>
</div>
</body>
</html>
<?PHP 
}
break;
case 'logout':
if(isset($_COOKIE["cartEpub"])){
foreach ($_COOKIE["cartEpub"] as $key=>$value) {
echo $key. ": ". $value;
setcookie("cartEpub[$key]","",time()-3600*24,"/");
}
unset($_COOKIE['cartEpub']);
}
if(isset($_COOKIE["userEpub"])){
foreach ($_COOKIE["userEpub"] as $key=>$value) {
echo $key. ": ". $value;
setcookie("userEpub[$key]","",time()-3600*24,"/");
}
unset($_COOKIE['userEpub']);
}

 ?>
<html>
<head>
<meta http-equiv="Refresh" content="5;url=../index.php">
</head>
<body>
<div class="row">
<div>Redirecting...<div>
<div>Successful Logout</div>
<div>if your browser does not redirect you in 5 seconds click <a href="../index.php">here</a></div>
</div>
</body>
</html>
<?PHP 
break;
default: ?>
<html>
<head>
<meta http-equiv="Refresh" content="5;url=../index.php">
</head>
<body>
<div class="row">
<div>Redirecting...<div>
<div>The action requested can not be processed</div>
<div>if your browser does not redirect you in 5 seconds click <a href="../index.php">here</a></div>
</div>
</body>
</html>
<?PHP
break;
}
}
else{?>
<html>
<head>
<meta http-equiv="Refresh" content="5;url=../index.php">
</head>
<body>
<div class="row">
<div>Redirecting...<div>
<div>No action submited</div>
<div>if your browser does not redirect you in 5 seconds click <a href="../index.php">here</a></div>
</div>
</body>
</html>
<?PHP
}
?>
