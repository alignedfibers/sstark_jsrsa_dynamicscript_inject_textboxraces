
<?php
/*function curPageURL() {
  $pageURL = '';
 if ($_SERVER["SERVER_PORT"] != "80") {
  $pageURL .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
 } else {
  $pageURL .= $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
 }
 return $pageURL;
}*/

if(isset($_SESSION['userEpub']['un']) && isset($_SESSION['userEpub']['status']) && isset($_SESSION['userEpub']['priv']) ){

if($_SESSION['userEpub']['status'] == 'logged'){	 
?>
<div class="opsPanel">
  <ul>
    <li>
<?PHP
if($_SESSION['userEpub']['priv'] == 'admin'){?>
<a href="../admin_tools/cp.php">
<?PHP }else{ ?>
    <a href="../user_tools/cp.php">
<?PHP } ?>
        <img src="../images/cp_icon.gif"/>
      </a>
    </li>
    <li>
      <a href="../shop/viewCart.php">
        <img src="../images/cart.gif"/>
      </a>
    </li>
  </ul>
  
</div>
<div class="right">

  <div class="right" width="218">

    <div class="row">
      Welcome &nbsp; <?PHP echo $_SESSION['userEpub']['un'].'.'; ?>
    </div>
    <div class="row">
      You are logged in.
    </div>
    <div class="row">
      <a href="../login_tools/log_tool.php?action=logout">Logout
      
      </a>
    </div>
  </div>

</div>
<?PHP }
elseif($_SESSION['userEpub']['status'] == 'notlogged'){ ?>
<div class="row right" width="218">
<form id=login_form name=login_form action="../login_tools/log_tool.php?action=login" method="post">
User Login

          <input size="15" name="user_name" id="user_name" class="search_fields" />
          
 <input size="15" type="password" name="password" id="password"  class="search_fields" />
         
                  <a href="../login_tools/register.php">Register</a>
                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <input name="submit" type="submit" value="Login" style="border:1px solid #999999; background-color:#CCCCCC; font-size:10px"/>
          
        </form></div><?PHP
}
}
else{
$_SESSION['userEpub']['un']= 'guest'; 
$_SESSION['userEpub']['status']= 'notlogged'; 
$_SESSION['userEpub']['priv']= 'guest';?>
<div class="right" width="218">
<form id=login_form name=login_form action="../login_tools/log_tool.php?action=login" method="post">
User Login
          <input size="15" name="user_name" id="user_name" class="search_fields" />
          
 <input size="15" type="password" name="password" id="password"  class="search_fields" />
         
                  <a href="../login_tools/register.php" >Register</a>
                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <input name="submit" type="submit" value="Login" style="border:1px solid #999999; background-color:#CCCCCC; font-size:10px"/>
          
        </form></div><?PHP

}
?>