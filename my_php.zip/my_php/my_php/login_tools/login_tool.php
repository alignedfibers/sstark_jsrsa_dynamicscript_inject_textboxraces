<?php
session_start(); 
$useName = $_GET['txtUserName'];
$pass = $_GET['txtPassword'];
$_SESSION['user']= $useName; 
$_SESSION['password']= $pass;
/*
echo $useName;
echo $pass;
*/

if (!isset($_GET[caller]))
{

}



if($useName == "admin" && $pass == "password"){
if (!isset($_GET[caller]))
{
header("Location: showServVars.php");
exit;
}


}
else{

header("Location: {$_SERVER["HTTP_REFERER"]}");
exit;
}

?>