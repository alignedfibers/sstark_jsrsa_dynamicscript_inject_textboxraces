<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-US">

<head>
	<style type="text/css" media="screen">
		@import url(../style.css);
	</style>
<?php session_start(); ?>
</head>

<body>

<div id="page_container" class="aligncenter">
<div id="top_row">
<div id='head_row_one'>
<?php
include '../includes/user_menu.php';

?>
</div>

<div id="clear_both" style="clear:both;"></div>


<div id="menu" class="right">
<ul class="top_nav">
<li><a href="portfolio/cover.php">Portfolio</a></li>
<li><a href="projects/project_listing.php">Projects</a></li>
<li><a href="contact/contact.php">Contact Me</a></li>
<li><a href="code/overview.php">Example Code</a></li>
<li><a href="shop/catalog.php">My Shop</a></li>
</ul>

</div>
<div id="clear_both" style="clear:both;"></div>
</div>
<div id="clear_both" style="clear:both;"></div>
<div id="main_row">

<div class="regform">
<div class="left">
<center>
<h1> You Must Register To Experience The Full Potential Of This Site</h1>
</center>
</div>
<form> 

 <table style="width:375px;">

<div class="row">
  	<DIV class="left">
	  <label for="fname"><small>First Name</small></label><br/>
	  <input type="text" name="fname" id="fname" value="" size="22" tabindex="1" />
  	</DIV>

  	<DIV class="right">
	  <label for="lname"><small>Last Name</small></label><br/>
	  <input type="text" name="lname" id="lname" value="" size="22" tabindex="2" />
  	</DIV>
</div>

   <div class="row">
	<DIV class="left">
	  <label for="addrs"><small>Address</small></label><br/>
	  <input type="text" name="addrs" id="addrs" value="" size="58" tabindex="3" />
	</DIV>
</div>
<div class="row">         
	<DIV class="left">
	  <label for="city"><small>City</small></label><br/>
	  <input type="text" name="city" id="city" value="" size="22" tabindex="4" />
	</DIV>

	<DIV class="left">
	  <label for="stateCmb"><small>&nbsp;&nbsp;&nbsp;&nbsp;State</small></label><br/>&nbsp;&nbsp;
	  <select size="1" name="stateCmb" id="stateCmb" tabindex="5" onchange=""><!--dspStateLbl()-->
	  <option value="AL">AL</option>
	  <option value="AK">AK</option>
	  <option value="AS">AS</option>
	  <option value="AZ">AZ</option>
	  <option value="AR">AR</option>
	  <option value="CA">CA</option>
	  <option value="CO">CO</option>
	  <option value="CT">CT</option>
	  <option value="DE">DE</option>
	  <option value="DC">DC</option>
	  <option value="FM">FM</option>
	  <option value="FL">FL</option> 
	  <option value="GA">GA</option> 
	  <option value="GU">GU</option>
	  <option value="HI">HI</option>
	  <option value="ID">ID</option>
	  <option value="IL">IL</option>
	  <option value="IN">IN</option>
	  <option value="IA">IA</option>
	  <option value="KS">KS</option>
	  <option value="KY">KY</option>
	  <option value="LA">LA</option>
	  <option value="ME">ME</option>
	  <option value="MH">MH</option>
	  <option value="MD">MD</option>
	  <option value="MA">MA</option>
	  <option value="MI">MI</option>
	  <option value="MN">MN</option>
	  <option value="MS">MS</option>
	  <option value="MO">MO</option>
	  <option value="MT">MT</option>
	  <option value="NE">NE</option>
	  <option value="NV">NV</option>
	  <option value="NH">NH</option>
	  <option value="NJ">NJ</option>
	  <option value="NM">NM</option>
	  <option value="NY">NY</option>
	  <option value="NC">NC</option>
	  <option value="ND">ND</option>
	  <option value="MP">MP</option>
	  <option value="OH">OH</option>
	  <option value="OK">OK</option>
	  <option value="OR">OR</option>
	  <option value="PW">PW</option>
	  <option value="PA">PA</option>
	  <option value="PR">PR</option>
	  <option value="RI">RI</option>
	  <option value="SC">SC</option>
	  <option value="SD">SD</option>
	  <option value="TN">TN</option>
	  <option value="TX">TX</option>
	  <option value="UT">UT</option>
	  <option value="VT">VT</option>
	  <option value="VI">VI</option>
	  <option value="VA">VA</option>
	  <option value="WA">WA</option>
	  <option value="WV">WV</option>
	  <option value="WI">WI</option>
	  <option value="WY">WY</option>
	  </select>
	</DIV>

	<DIV class="right">
	  <label for="zip"><small>&nbsp;&nbsp;&nbsp;&nbsp;Zip</small></label><br/>&nbsp;&nbsp;&nbsp;
	  <input type="text" name="zip" id="zip" value="" size="12" tabindex="6" />
  	</DIV>
</div>
<div class="row">
	<DIV class="left">
	  <label for="tPhone"><small>Telephone</small></label><br/>
	  <input type="text" name="tPhone" id="tPhone" value="" size="22" tabindex="7" />
	</DIV>
	<DIV class="right">
	  <label for="cPhone"><small>&nbsp;&nbsp;&nbsp;&nbsp;Cell</small></label><br/>&nbsp;&nbsp;&nbsp;
	  <input type="text" name="cPhone" id="cPhone" value="" size="22" tabindex="8" />
  	</DIV>
  	
</div>
<div class="row">
	<DIV class="left">
	  <label for="email"><small>E-mail</small></label><br/>
	  <input type="text" name="email" id="email" value="" size="35" tabindex="9" />
  	</DIV>
	<DIV class="right">
	  <label for="bDay"><small>Date Of Birth</small></label><br/>
	  <input type="text" name="bDay" id="bDy" value="" size="8" tabindex="10" />
  	</DIV>
</div>
<div class="row">
  	<DIV class="left">
	  <label for="un"><small>User Name</small></label><br/>
	  <input type="text" name="un" id="un" value="" size="27" tabindex="11" />
  	</DIV>
  	<DIV class="right">
	  <label for="pass">Password</small></label><br/>
	  <input type="text" name="pass" id="pass" value="" size="20" tabindex="11" />
  	</DIV>
</div>

<div class="row">
	<DIV class="left">
	  <p>
	  <input type="button" value="register" onclick="validateform();">
	  </p>
	</DIV>
</div>
</table>


</form>
</div>

</div>
<div id="bottom_row">
where ami
</div>

<div id="clear_both" style="clear:both;"></div>
</div>




</body>
</html>