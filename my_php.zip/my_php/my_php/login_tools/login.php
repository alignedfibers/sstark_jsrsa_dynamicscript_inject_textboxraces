<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-US">

<head>
	<style type="text/css" media="screen">
		@import url(../style.css);
	</style>
<?php session_start(); ?>
</head>

<body>

<div id="page_container" class="aligncenter">
<div id="top_row">
<div id='head_row_one'>

<?php
include'../includes/user_menu.php';
?>
</div>

<div class="row"></div>


<div id="menu" class="row right">
<ul class="top_nav">
<li><a href="../portfolio/cover.php">Portfolio</a></li>
<li><a href="../projects/project_listing.php">Projects</a></li>
<li><a href="../contact/contact.php">Contact Me</a></li>
<li><a href="../code/overview.php">Example Code</a></li>
<li><a href="../shop/catalog.php">My Shop</a></li>
</ul>

</div>
<div id="clear_both" style="clear:both;"></div>
</div>
<div id="clear_both" style="clear:both;"></div>
<div id="main_row">
  <?PHP
if(isset($_SESSION['userEpub']['un']) && isset($_SESSION['userEpub']['status']) && isset($_SESSION['userEpub']['priv']) ){

if($_SESSION['userEpub']['status'] == 'logged'){	 ?>
<div class="right" width="218">
<div class="row">
<center><h1>Sorry&nbsp; <?PHP echo $_SESSION['userEpub']['un'].'.'; ?></h1></center>
</div>
<div class="row">
<center><h1>You are already logged in.</h1></center>
</div>
<div class="row">
To complete this action
<a href="../login_tools/log_tool.php?action=logout">logout</a>
</div>
<div class="row">
<a href ="../login_tools/log_tool.php?action=logout">Logout</a>
</div>
<?PHP }} ?>
<center>
<h2>Login Form</h2>
</center>
<center>
<div class="logform">

  <form id="log_page_form" name="log_page_form" action="../login_tools/log_tool.php?action=login" method="post"> 

 <table style="width:375px;">

<div class="row">
                <DIV class="left">
	  <label for="user_name"><small>First Name</small></label><br/>
	  <input type="text" name="user_name" id="user_name" value="" class="search_fields" size="15" tabindex="1" />
  	</DIV>
  	
</div>

   <div class="row">
                 <DIV class="left">
	  <label for="password"><small>Password</small></label><br/>
	  <input type="text" name="password" id="password" value="" class="search_fields"size="15" tabindex="2" />
	</DIV>
</div>



<div class="row">
	<DIV class="left">
	  <p>
	  <input name="submit" type="submit" value="Login" style="border:1px solid #999999; background-color:#CCCCCC; font-size:10px"/>
	  </p>
	</DIV>
</div>
</table>


</form>
</div>
</center>

</div>
<div id="bottom_row">
where ami
</div>

<div id="clear_both" style="clear:both;"></div>
</div>




</body>
</html>