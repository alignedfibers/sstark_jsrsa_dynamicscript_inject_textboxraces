<?PHP //This script will fail if you havn't set the file Location in conConfig
/****************************************************************/
//Database Operations, Written by Shawn Nicholas Stark 11.24.2008

include '../includes/conf.php';
$conn = new COM("ADODB.Connection"); 
$conn->provider = "Microsoft.Jet.OLEDB.4.0";
$conn->open($fileLoc);

/**************************************************************
Alternative ADODB connection method

$conn = new COM("ADODB.Connection"); 
$connStr = "DRIVER={Microsoft Access Driver (*.mdb)}; DBQ=$fileLocation; DefaultDir=$defaultDir"; 
$conn->open($connStr); 
***************************************************************/



/***************************************************************
Current Functions in itemDbAdapter are listAll(), and search(), 
listSubSetById(), updateSubSetById() delete() 12.18.2008
****************************************************************/

class itemsDbAdapter{

/******************************
List All Function PUBLIC
Returns an array of rows
******************************/
public function listAll(){

global $conn;
$rs = $conn->execute('SELECT * FROM Items');
$resultList = "";
$holdArray = "";
while (!$rs->EOF) {

$holdArray['imagePath'] = (string)$rs->Fields('imagePath');
$holdArray['itemID'] = (string)$rs->Fields('itemID');
$holdArray['description'] = (string)$rs->Fields('description');
$holdArray['price'] = '$'.number_format((string)$rs->Fields('price'),2);
  
$resultList[] = $holdArray;  

    $rs->MoveNext();    



}


return $resultList;
}

/********************************************************
Used in conjunction with parsing strings to create an SQL statement.
returns a string only alphaNumeric with space
********************************************************/
private function trimKeepSpace($value) 
{ 
    $value = preg_replace("/[^a-z \d]/i", "", $value);
    //$value = preg_replace("/[^a-zA-Z0-9s]/", "", $value); 
    return $value;
}

public function trimWithComma($value) 
{ 
    
    $value = preg_replace("/[^a-zA-Z0-9,]/", "", $value); 
    return $value;
}

public function trimAll($value) 
{ 
    
    $value = preg_replace("/[^a-zA-Z0-9]/", "", $value); 
    return $value;
}

/***********************************************************************
This function returns a multidimensional array of records and specified
field values for each record within the range of the lower and upper bounds 
This will fail if the record has a null value in one of the fields
or there is some other error.
***********************************************************************/
public function listSubSetByID($Lbound, $Ubound, $fieldsCdelim){
$fieldsCdelim = $this->trimWithComma($fieldsCdelim);
$fieldNames = explode(',',$fieldsCdelim);
$sqlStr = 'SELECT ';
foreach($fieldNames as $key=>$value){
$sqlStr.= $value.', ';
}

$sqlStr = substr_replace ($sqlStr, '', -2 , 2);
$sqlStr.= ' FROM Items WHERE itemID BETWEEN \''.$Lbound.'\' AND \''.$Ubound.'\'';
global $conn;
//echo $sqlStr;
try{
$rs = $conn->execute($sqlStr);
$resultList = "";
$holdArray = "";

while (!$rs->EOF) {
//echo 'rs loop';
foreach($fieldNames as $key=>$value){
//echo (string)$rs->Fields($value);
$holdArray[$value] = (string)$rs->Fields($value);
}

$resultList[] = $holdArray;  

    $rs->MoveNext();    
}


return $resultList;
}
catch(Exception $e)
{
exit('This request can not be processed.<br/> Please return to the form that brought you here. <br/>'.$e->getMessage());
}

}

/****************************************************************************************************
Using SQL wildcard %  a where statement is created referencing description with the wild criteria. 
The where statement is created by parsing the string delimited by a space, explode($string, ' ') 
also checked and delimited by quotations to ensure full string match LATER for grouping. 
All quatations and other programing characters are removed. Only searching description right now. 
I may create a seperate function to search each different column which would be the prefered method 
on this table as it is unlikely to find similar data between imagePath, ItemID, price and description 
so I would give the users the option to search by price range, description or item id LATER.
*****************************************************************************************************/

public function search($searchStr){
$sqlStr = "SELECT * FROM Items WHERE";
$searchStr = $this->trimKeepSpace($searchStr);
$searchVals = explode ( ' ', $searchStr );

foreach($searchVals as $key => $value ){
$sqlStr = $sqlStr.' description LIKE \'%'.$value.'%\' OR';
}
$sqlStr = substr_replace ($sqlStr, '', -2 , 2);
global $conn; 
$rs = $conn->execute($sqlStr);
$resultList = "";
$holdArray = "";

while (!$rs->EOF) {

$holdArray['imagePath'] = (string)$rs->Fields('imagePath');
$holdArray['itemID'] = (string)$rs->Fields('itemID');
$holdArray['description'] = (string)$rs->Fields('description');
$holdArray['price'] = '$'.number_format((string)$rs->Fields('price'),2);
  
$resultList[] = $holdArray;  

    $rs->MoveNext();    



}
return $resultList;
}

public function updateSubSet($Lbound,$Ubound,$fields,$fldVals){
global $conn;

$fields = $this->trimWithComma($fields);
$fields = explode(',',$fields);
$fldVals = explode(',',$fldVals);

$sqlStr = 'Update Items SET ';

foreach($fields As $key=>$value){

$sqlStr = $sqlStr.$value.'= \''.$fldVals[$key].'\', ';
 
}
$sqlStr =  substr_replace($sqlStr,'',-2,2);

$sqlStr = $sqlStr.'WHERE itemID BETWEEN \''.$Lbound.'\' AND \''.$Ubound.'\''; 


try{
$rs = $conn->execute($sqlStr);
return 'true';
}
catch(Exception $e)
{
return 'false';
}

}

public function insertSubSet($Lbound,$Ubound,$fields,$fldVals){
global $conn;

$fields = $this->trimWithComma($fields);
$fields = explode(',',$fields);
$fldVals = explode(',',$fldVals);

$sqlStr = 'INSERT INTO Items (';

foreach($fields As $key=>$value){

$sqlStr = $sqlStr.$value.', ';
 
}
$sqlStr =  substr_replace($sqlStr,'',-2,2);

$sqlStr = $sqlStr.') VALUES (';

foreach($fldVals as $key=>$value){
$sqlStr.= '\''.$value.'\',';
}
$sqlStr =  substr_replace($sqlStr,'',-1,1);

$sqlStr.= ' )';
echo $sqlStr;


try{
$rs = $conn->execute($sqlStr);
return 'true';
}
catch(Exception $e)
{
echo $e->getMessage();
die();
return 'false';
}

}


public function delete($id){
global $conn;
$sqlStr = 'DELETE FROM Items WHERE itemID BETWEEN \''.$id.'\' AND \''.$id.'\'';
echo $sqlStr;
try{
$rs = $conn->execute($sqlStr);
return 'true';
}

catch(Exception $e){
return 'false';
}
}
}

?>