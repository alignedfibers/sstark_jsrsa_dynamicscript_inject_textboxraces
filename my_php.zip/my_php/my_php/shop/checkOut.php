
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-US">

<head>
	<style type="text/css" media="screen">
		@import url(../style.css);
	</style>
<?php session_start(); ?>
</head>

<body>

<div id="page_container" class="aligncenter">
<div id="top_row">
<div id='head_row_one'>
<?php 
include 'dbOps.php';
include '../includes/dbOps.php';
//The two adapters below will be combined into one.
$dbObj = new itemsDbAdapter;
$uDbObj = new dbAdapter;
include '../includes/user_menu.php'
?>
</div>

<div id="clear_both" style="clear:both;"></div>


<div id="menu" class="right">
<ul class="top_nav">
<li><a href="../portfolio/cover.php">Portfolio</a></li>
<li><a href="../projects/project_listing.php">Projects</a></li>
<li><a href="../contact/contact.php">Contact Me</a></li>
<li><a href="../code/overview.php">Example Code</a></li>
<li><a href="../shop/catalog.php">My Shop</a></li>
</ul>

</div>
<div class="clear_both" style="clear:both;"></div>
</div>
<div class="clear_both" style="clear:both;"></div>
<div id="main_row">
<div id="left_container">
<!--<img src="chair_tilt.gif" class"alignleft" id="left_chair_one"/>-->
</div>
  <div id="right_container">
    <?PHP
if(isset($_SESSION['userEpub']['un']) && isset($_SESSION['userEpub']['status']) && isset($_SESSION['userEpub']['priv']) ){

if($_SESSION['userEpub']['status'] == 'logged'){	 
if(isset($_SESSION['cartEpub'])&& count($_SESSION['cartEpub'])>0){

              $matchingUsers = $uDbObj->getSubsetByFields('Users','FirstName,LastName,Address,City,State,Zip,Teliphone,Cell,Email','UserID',$_SESSION['userEpub']['id']);
              if ( !is_array($matchingUsers) || empty($matchingUsers) ) { ?>
    <html>
      <head>
        <meta http-equiv="Refresh" content="5;url=../login_tools/login.php">
        </head>
      <body>
        <div class="row">
          <div>
            Redirecting...<div>
              <div>
                You are logged in with a user not found in the database.<br/>
                Please log out and log back in. You will loose all items currently in your cart.<br/>
                Contact administrator
              </div>
              <div>
                if your browser does not redirect you in 5 seconds click <a href="../login_tools/login.php">here</a>
              </div>
            </div>
          </body>
    </html>
    <?PHP }

         elseif ( count($matchingUsers) > 1 ){?>
    <html>
      <head>
        <meta http-equiv="Refresh" content="5;url=../login_tools/login.php">
        </head>
      <body>
        <div class="row">
          <div>
            Redirecting...<div>
              <div>Database Integrity Problem, please logout and contact administrator</div>
              <div>
                if your browser does not redirect you in 5 seconds click <a href="../login_tools/login.php">here</a>
              </div>
            </div>
          </body>
    </html>
    <?PHP }else{?>

    <center>
      <h4>Check Out</h4>
      <!--<div class="cntrNote">  
After verifing this order and adding a few more pieces of information<br/>
You will be provided with a reference number and an itemized list of your<br/>
purchase. A downloadable pdf of the order reciept will be available. You <br/>
will also recieve an e-mail with the reference numbers, customer service<br/>
contact, and estamated date of shipment. A final e-mail will be sent to you<br/>
upon the shipment and completion of the order. If for any reason you would<br/>
like to cancel this order, contact customer service prior to recieving the<br/>
final e-mail and we will refund your order minus the shipping and handling <br/>
charges. If you do not finish the order by pressing submit to paypal the<br/>
order will be considered open and you will find a link to finish submitting<br/>
it under My orders in your control panel. NOTICE this site doesn't handle any<br/>
actual transactions of money. We trust that paypal will handle the transaction<br/>
well. We do ensure that you can enquire and find out the exact details of your<br/>
order at any time.  <br/>
</div>-->
    </center>
    <table width="52%" style="float: left;">
      <tr>
        <td>
          <table width="100%" border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td>
                <table width="100%" border="0" cellspacing="2" cellpadding="0">
                  <tr valign="top">
                    <td width="75%" height="20">
                      <b>Product Description</b>
                    </td>
                    <td width="5%" height="20">
                      <div align="center">
                        <b>QTY</b>
                      </div>
                    </td>
                    <td width="20%" height="20">
                      <div align="right">
                        <b>Price</b>
                      </div>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
            <tr valign="top" bgcolor="#E3E3E3">
              <td colspan="3" height="20">
                <table width="100%" border="0" cellspacing="0" cellpadding="5" >


                  <?PHP

static $cstTtl = 0;
$itmDet;
$cstHld = 0;
foreach($_SESSION['cartEpub'] as $key => $value){
  $itmDet = $dbObj->listSubSetByID($key,$key,
  'price,description');
  $cstHld = $itmDet[0]['price'];
  $cstTtl = $cstTtl + ($cstHld*$value); ?>
                  <tr>
                    <td>
                      <?PHP echo $key ; ?>
                      &nbsp;<?PHP echo $itmDet[0]['description'] ?>
                    </td>
                    <td>
                      <?PHP echo $value; ?>
                    </td>
                    <td>
                      <?PHP echo '$'.number_format(($cstHld*$value),2); ?>
                    </td>
                  </tr>
                  <?PHP }?>
                  <tr>
                    <td>
                      <hr/>
                      <?PHP echo 'Total Price: '.'$'.number_format($cstTtl,2);?>
                    </td>

                  </tr>
                </table>
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>
    </td>
    </tr>
    </table>
    <form id="ord_page_form" name="ord_page_form" action="<?PHP echo 'save_order.php?action=insert'; ?>" method="post">
        <?PHP if(isset($_SESSION['cartEpub'])){
      static $cstTtl = 0;
      $itmDet;
      $cstHld = 0;
      foreach($_SESSION['cartEpub'] as $key => $value){
      $itmDet = $dbObj->listSubSetByID($key,$key,
      'price,description');
      $cstHld = $itmDet[0]['price'];
      $cstTtl = $cstTtl + ($cstHld*$value); ?>
        <input type="hidden" name="items["
          <?PHP echo $key ?>
            ]" value="<?PHP echo $value; ?>">
            <?PHP }echo '<input type="hidden" name="total" value="'.$cstTtl.'">';}else{}?>
            <table width="40%" style="float:left;">

              <tr>
                <td>
                  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                    <tr>
                      <td height="20">
                        <center>
                          <b>Billing Information</b>
                        </center>
                      </td>
                    </tr>
                  </table>
                </td>
              </tr>


              <tr>
                <td>
                  <table width="100%"  cellspacing="1">


                    <div class="row">
                      <DIV class="left">
                        <label for="bFname">
                          <small>*First Name</small>
                        </label>
                        <br/>
<input type="text" name="bFname" id="bFname" value="<?PHP echo $matchingUsers[0]['FirstName']; ?>" size="17.5" tabindex="1" />
                          </DIV>
                      <DIV class="left" style="padding-left:5px;">
                        <label for="bLname">
                          <small>*Last Name</small>
                        </label>
                        <br/>
                        <input type="text" name="bLname" id="bLname" value="<?PHP echo $matchingUsers[0]['LastName']; ?>" size="17.5" tabindex="2" />
                      </DIV>
                    </div>
                    <div class="row">
                      <DIV class="left">
                        <label for="bAddr">
                          <small>*Billing Address</small>
                        </label>
                        <br/>
                        <input type="text" name="bAddr" id="bAddr" value="<?PHP echo $matchingUsers[0]['Address']; ?>" size="39" tabindex="3" />
                      </DIV>
                    </div>
                    <div class="row">
                      <DIV class="left">
                        <label for="bCity">
                          <small>*City</small>
                        </label>
                        <br/>
                        <input type="text" name="bCity" id="bCity" value="<?PHP echo $matchingUsers[0]['City']; ?>" size="28" tabindex="4" />
                      </DIV>

                      <DIV class="left">
                        <label for="bStateCmb">
                          <small>&nbsp;&nbsp;&nbsp;&nbsp;*State</small>
                        </label><br/>&nbsp;&nbsp;&nbsp;
                        <select size="1" name="bStateCmb" id="bStateCmb" tabindex="5" onchange="">
                          <!--dspStateLbl()-->
                          <option id="AL" name="AL" value="AL">AL</option>
                          <option id="AK" name="AK" value="AK">AK</option>
                          <option id="AS" name="AS" value="AS">AS</option>
                          <option id="AZ" name="AZ" value="AZ">AZ</option>
                          <option id="AR" name="AR" value="AR">AR</option>
                          <option id="CA" name="CA" value="CA">CA</option>
                          <option id="CO" name="CO" value="CO">CO</option>
                          <option id="CT" name="CT" value="CT">CT</option>
                          <option id="DE" name="DE" value="DE">DE</option>
                          <option id="DC" name="DC" value="DC">DC</option>
                          <option id="FM" name="FM" value="FM">FM</option>
                          <option id="FL" name="FL" value="FL">FL</option>
                          <option id="GA" name="GA" value="GA">GA</option>
                          <option id="GU" name="GU" value="GU">GU</option>
                          <option id="HI" name="HI" value="HI">HI</option>
                          <option id="ID" name="ID" value="ID">ID</option>
                          <option id="IL" name="IL" value="IL">IL</option>
                          <option id="IN" name="IN" value="IN">IN</option>
                          <option id="IA" name="IA" value="IA">IA</option>
                          <option id="KS" name="KS" value="KS">KS</option>
                          <option id="KY" name="KY" value="KY">KY</option>
                          <option id="LA" name="LA" value="LA">LA</option>
                          <option id="ME" name="ME" value="ME">ME</option>
                          <option id="MH" name="MH" value="MH">MH</option>
                          <option id="MD" name="MD" value="MD">MD</option>
                          <option id="MA" name="MA" value="MA">MA</option>
                          <option id="MI" name="MI" value="MI">MI</option>
                          <option id="MN" name="MN" value="MN">MN</option>
                          <option id="MS" name="MS" value="MS">MS</option>
                          <option id="MO" name="MO" value="MO">MO</option>
                          <option id="MT" name="MT" value="MT">MT</option>
                          <option id="NE" name="NE" value="NE">NE</option>
                          <option id="NV" name="NV" value="NV">NV</option>
                          <option id="NH" name="NH" value="NH">NH</option>
                          <option id="NJ" name="NJ" value="NJ">NJ</option>
                          <option id="NM" name="NM" value="NM">NM</option>
                          <option id="NY" name="NY" value="NY">NY</option>
                          <option id="NC" name="NC" value="NC">NC</option>
                          <option id="ND" name="ND" value="ND">ND</option>
                          <option id="MP" name="MP" value="MP">MP</option>
                          <option id="OH" name="OH" value="OH">OH</option>
                          <option id="OK" name="OK" value="OK">OK</option>
                          <option id="OR" name="OR" value="OR">OR</option>
                          <option id="PW" name="PW" value="PW">PW</option>
                          <option id="PA" name="PA" value="PA">PA</option>
                          <option id="PR" name="PR" value="PR">PR</option>
                          <option id="RI" name="RI" value="RI">RI</option>
                          <option id="SC" name="SC" value="SC">SC</option>
                          <option id="SD" name="SD" value="SD">SD</option>
                          <option id="TN" name="TN" value="TN">TN</option>
                          <option id="TX" name="TX" value="TX">TX</option>
                          <option id="UT" name="UT" value="UT">UT</option>
                          <option id="VT" name="VT" value="VT">VT</option>
                          <option id="VI" name="VI" value="VI">VI</option>
                          <option id="VA" name="VA" value="VA">VA</option>
                          <option id="WA" name="WA" value="WA">WA</option>
                          <option id="WV" name="WV" value="WV">WV</option>
                          <option id="WI" name="WI" value="WI">WI</option>
                          <option id="WY" name="WY" value="WY">WY</option>
                        </select>
                      </DIV>
                      <script type="text/javascript">
                        curState = document.getElementById('<?PHP echo $matchingUsers[0]['State']; ?>');
                        curState.selected = true;
                      </script>
                    </div>
                    <div class="row">
                      <DIV class="left">
                        <label for="bZip">
                          <small>*Zip</small>
                        </label>
                        <br/>
                        <input type="text" name="bZip" id="bZip" value="<?PHP echo $matchingUsers[0]['Zip']; ?>" size="28" tabindex="4" />
                      </DIV>

                      <DIV class="left">
                        <label for="bCntry">
                          <small>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*Country</small>
                        </label>
                        <br/>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Country
                      </DIV>
                    </div>
                    <div class="row">
                      <DIV class="left">
                        <label for="bPnum">
                          <small>*Landline</small>
                        </label>
                        <br/>
                        <input type="text" name="bPnum" id="bPnum" value="<?PHP echo $matchingUsers[0]['Teliphone']; ?>" size="17.5" tabindex="4" />
                      </DIV>
                      <DIV class="left" style="padding-left:5px;">
                        <label for="bCnum">
                          <small>Cell Phone</small>
                        </label>
                        <br/>
                        <input type="text" name="bCnum" id="bCnum" value="<?PHP echo $matchingUsers[0]['Cell']; ?>" size="17.5" tabindex="4" />
                      </DIV>
                    </div>
                    <div class="row">
                      <DIV>
                        <label for="bEmail">
                          <small>*Email</small>
                        </label>
                        <br/>
                        <input type="text" name="bEmail" id="bEmail" value="<?PHP echo $matchingUsers[0]['Email']; ?>" size="39" tabindex="4" />
                      </DIV>

                    </div>

                  </table>
                </td>
              </tr>

              <tr>
                <td>
                  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                    <tr>
                      <td height="20">
                        <center>
                          <b>Shipping Information</b>
                        </center>
                      </td>
                    </tr>
                  </table>
                </td>
              </tr>
              <tr>
                <td>
                  <table width="100%"  cellspacing="1">
                    <div class="row">
                      <DIV class="left">
                        <label for="sFname">
                          <small>*First Name</small>
                        </label>
                        <br/>
                        <input type="text" name="sFname" id="sFname" value="" size="17.5" tabindex="1" />
                      </DIV>
                      <DIV class="left" style="padding-left:5px;">
                        <label for="sLname">
                          <small>*Last Name</small>
                        </label>
                        <br/>
                        <input type="text" name="sLname" id="sLname" value="" size="17.5" tabindex="2" />
                      </DIV>
                    </div>

                    <div class="row">
                      <DIV class="left">
                        <label for="sAddr">
                          <small>*Shipping Address</small>
                        </label>
                        <br/>
                        <input type="text" name="sAddr" id="sAddr" value="" size="39" tabindex="3" />
                      </DIV>
                    </div>
                    <div class="row">
                      <DIV class="left">
                        <label for="sCity">
                          <small>City</small>
                        </label>
                        <br/>
                        <input type="text" name="sCity" id="sCity" value="" size="28" tabindex="4" />
                      </DIV>

                      <DIV class="left">
                        <label for="sStateCmb">
                          <small>&nbsp;&nbsp;&nbsp;&nbsp;State</small>
                        </label><br/>&nbsp;&nbsp;&nbsp;
                        <select size="1" name="sStateCmb" id="stateCmb" tabindex="5" onchange="">
                          <!--dspStateLbl()-->
                          <option value="AL">AL</option>
                          <option value="AK">AK</option>
                          <option value="AS">AS</option>
                          <option value="AZ">AZ</option>
                          <option value="AR">AR</option>
                          <option value="CA">CA</option>
                          <option value="CO">CO</option>
                          <option value="CT">CT</option>
                          <option value="DE">DE</option>
                          <option value="DC">DC</option>
                          <option value="FM">FM</option>
                          <option value="FL">FL</option>
                          <option value="GA">GA</option>
                          <option value="GU">GU</option>
                          <option value="HI">HI</option>
                          <option value="ID">ID</option>
                          <option value="IL">IL</option>
                          <option value="IN">IN</option>
                          <option value="IA">IA</option>
                          <option value="KS">KS</option>
                          <option value="KY">KY</option>
                          <option value="LA">LA</option>
                          <option value="ME">ME</option>
                          <option value="MH">MH</option>
                          <option value="MD">MD</option>
                          <option value="MA">MA</option>
                          <option value="MI">MI</option>
                          <option value="MN">MN</option>
                          <option value="MS">MS</option>
                          <option value="MO">MO</option>
                          <option value="MT">MT</option>
                          <option value="NE">NE</option>
                          <option value="NV">NV</option>
                          <option value="NH">NH</option>
                          <option value="NJ">NJ</option>
                          <option value="NM">NM</option>
                          <option value="NY">NY</option>
                          <option value="NC">NC</option>
                          <option value="ND">ND</option>
                          <option value="MP">MP</option>
                          <option value="OH">OH</option>
                          <option value="OK">OK</option>
                          <option value="OR">OR</option>
                          <option value="PW">PW</option>
                          <option value="PA">PA</option>
                          <option value="PR">PR</option>
                          <option value="RI">RI</option>
                          <option value="SC">SC</option>
                          <option value="SD">SD</option>
                          <option value="TN">TN</option>
                          <option value="TX">TX</option>
                          <option value="UT">UT</option>
                          <option value="VT">VT</option>
                          <option value="VI">VI</option>
                          <option value="VA">VA</option>
                          <option value="WA">WA</option>
                          <option value="WV">WV</option>
                          <option value="WI">WI</option>
                          <option value="WY">WY</option>
                        </select>
                      </DIV>
                    </div>
                    <div class="row">
                      <DIV class="left">
                        <label for="sZip">
                          <small>*Zip</small>
                        </label>
                        <br/>
                        <input type="text" name="sZip" id="sZip" value="" size="28" tabindex="4" />
                      </DIV>

                      <DIV class="left">
                        <label for="sCntry">
                          <small>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*Country</small>
                        </label>
                        <br/>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Country
                      </DIV>
                    </div>

                    <div class="row">
                      <DIV class="left">
                        <label for="sPnum">
                          <small>*Landline</small>
                        </label>
                        <br/>
                        <input type="text" name="sPnum" id="sPnum" value="" size="17.5" tabindex="4" />
                      </DIV>
                      <DIV class="left" style="padding-left:5px;">
                        <label for="sCnum">
                          <small>Cell Phone</small>
                        </label>
                        <br/>
                        <input type="text" name="sCnum" id="sCnum" value="" size="17.5" tabindex="4" />
                      </DIV>
                    </div>

                  </table>


                </td>
              </tr>
              <tr>
                <td>
                  <div class="row">
                    <DIV class="left">
                      <p>
                        <input name="submit" type="submit" value="order" style="border:1px solid #999999; background-color:#CCCCCC; font-size:10px"/>
                      </p>
                    </DIV>
                  </div>
                </td>
              </tr>
            </table>
          </form>



    <?PHP }}else{ ?>
    <html>
      <head>
        <meta http-equiv="Refresh" content="5;url=../shop/catalog.php"/>
        </head>
      <body>
        <div class="row">
          <div>
            Redirecting...</div>
              <div>

              </div>
              <div>
                Please add some items in your cart prior to checkout<br/>
                If you are not redirected click&nbsp;<a href="../login_tools/login.php">here</a>
              </div>
            </div>
          
          </body>
    
    </html>
    <?PHP }} else{ ?>
    <center>
      You Must&nbsp;<a href="../login_tools/register.php">register</a>&nbsp; AND/OR&nbsp;<a href="../login_tools/login.php">login</a>&nbsp; to complete the checkout process <br/>
      You will not loose any information in the mean time while you complete the registration or login
    </center>
    <?PHP }}else{ ?>
    <center>
      You Must&nbsp;<a href="../login_tools/register.php">register</a>&nbsp; AND/OR&nbsp;<a href="../login_tools/login.php">login</a>&nbsp; to complete the checkout process <br/>
      You will not loose any information in the mean time while you complete the registration or login
    </center>
    <?PHP } ?>
  </div>
  <div class="clear_both" style="clear:both;"></div>
<div id="bottom_row">
where ami
</div>

<div class="clear_both" style="clear:both;"></div>
</div>




</body>
</html>

