<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-US">

  <head>
    <style type="text/css" media="screen">
      @import url(../style.css);
    </style>
    <?php session_start(); ?>
  </head>

  <body>

    <div id="page_container" class="aligncenter">
      <div id="top_row">
        <div id='head_row_one'>
          <?php 

include '../includes/user_menu.php'
?>
        </div>

        <div id="clear_both" style="clear:both;"></div>


        <div id="menu" class="right">
          <ul class="top_nav">
            <li>
              <a href="../portfolio/cover.php">Portfolio</a>
            </li>
            <li>
              <a href="../projects/project_listing.php">Projects</a>
            </li>
            <li>
              <a href="../contact/contact.php">Contact Me</a>
            </li>
            <li>
              <a href="../code/overview.php">Example Code</a>
            </li>
            <li>
              <a href="../shop/catalog.php">My Shop</a>
            </li>
          </ul>

        </div>
        <div class="clear_both" style="clear:both;"></div>
      </div>
      <div class="clear_both" style="clear:both;"></div>
      <div id="main_row">
        <div id="left_container">
          <!--<img src="chair_tilt.gif" class"alignleft" id="left_chair_one"/>-->
        </div>
        <div id="right_container">
    <?PHP 
/*Update Cart written by Shawn Stark 11.12.2008*/

/******************************************** 
This page should display successful update with
links to view cart and also to view catalog. Should
also display a message for unsuccessful update
with a link to view cart and catalog.
ALL ERRORS AND BUGS FIXED 11.24.2008
HUH forgot to check null and empty values 12.17.2008
QTY must be tested to ensure it is numeric,
not casted but tested returning an error message. 

functions include clearone, clearall, add, remove
*********************************************/
$myCart = new cart;
$display = $myCart->processUpdate();
echo $display['display'];

/***********************************************************
My very first PHP class 
************************************************************/
class cart{ 

private $updateType = 'not defined';

private function addItem(){


/****************************************************
See if there is an entry for the item. If there is an entry update its 
value by the increment provide by the quanity url parrameter. 
Else add a new item to the session array. 
*****************************************************/
$errorList[0] = "";
$addRunStats['updateSuccessful'] = 'false';
$addRunStats['display'] = '<center><strong>Please Contact Administrator</strong></center>';
$addRunStats['errorList'] = $errorList;
try{
if (isset($_GET["itemID"]) && isset($_GET["quantity"])){
//echo 'parrams checked and are set; ADD';
/****************************************************************
            Update Exsisting Item QTY if Item Exsists in Cart
*****************************************************************/
        if (isset($_SESSION['cartEpub'][$_GET["itemID"]])){
        
        
       /************************************************************************************
	  If requested quantity exceeds inventory quantity write error..
	  If inventory(item#)[qty] > $_GET["quantity"]+$_SESSION[$_GET["itemID"]]{
		$addRunStats['updateSuccessful'] = 'false';
		$addRunStats['errorList'][] = 'Update Action Add Failed. Quantity Requested exceeds inventory'}else{
      *************************************************************************************/
          if($_GET['quantity'] < 0 && $_GET['quantity']!= '' ){
            $addRunStats['updateSuccessful'] = 'false';
            $addRunStats['errorList'][] = 'Update Action Add Failed. Quantity Requested Can Not be Negative';
    }elseif($_GET['quantity'] == '' || $_GET['quantity'] == null){

                $addRunStats['updateSuccessful'] = 'false';
            $addRunStats['errorList'][] = 'Update Action Add Failed. Quantity must have a value';
    
    }else{
               $_SESSION['cartEpub'][$_GET['itemID']] = $_SESSION['cartEpub'][$_GET['itemID']]+$_GET['quantity'] ;
                $addRunStats['updateSuccessful'] = 'true';}

}


/****************************************************************
	Add New Item and QTY if Item does not exsist in cart.
*****************************************************************/
        else{ 
       /************************************************************************************
	If requested quantity exceeds inventory quantity write error..
	If inventory(item#)[qty] > $_GET["quantity"]{
		$addRunStats['updateSuccessful'] = 'false';
		$addRunStats['errorList'][] = 'Update Action Add Failed. Quantity Requested exceeds inventory'}else{
       **************************************************************************************/ 
   if($_GET['quantity'] < 0){
            $addRunStats['updateSuccessful'] = 'false';
            $addRunStats['errorList'][] = 'Update Action Add Failed. Quantity Requested Can Not be Negative';
    }elseif($_GET['quantity'] == '' || $_GET['quantity'] == null){
                $addRunStats['updateSuccessful'] = 'false';
            $addRunStats['errorList'][] = 'Update Action Add Failed. Quantity must have a value';
    }else{
     $_SESSION['cartEpub'][$_GET["itemID"]] = $_GET["quantity"];
	    $addRunStats['updateSuccessful'] = 'true';}
                  }

}else{ 
/****************************************************************
	Required url parrams not defined, write error
*****************************************************************/
	    if(!isset($_GET["itemID"]) || !isset($_GET["quantity"])){
	    $addRunStats['errorList'][] = 'Update Action Add Failed. itemId or Quantity not defined'; 
                    }
	    /*if(!isset($_GET["quantity"]){
	    $addRunStats['errorList'][] = 'Update Action Add Failed. quantity not defined.';
	    }*/
	    $addRunStats['updateSuccessful'] = 'false';
     }
     
}//END TRY
catch(Exception $e)
{
/****************************************************************
	other errors
*****************************************************************/
$addRunStats['errorList'][] = $e->getMessage();
}

return $addRunStats;
}



private function removeItem(){
/****************************************************
see if there is an entry for the item if there is an entry, update its 
value by the -increment provided by the quanity url parrameter 
Else log error and return unsuccessful.
*****************************************************/
$errorList[0] = "";
$removeRunStats['updateSuccessful'] = 'false';
$removeRunStats['display'] = '<center><strong>Please Contact Administrator</strong></center>';
$removeRunStats['errorList'] = $errorList;
try{
if (isset($_GET["itemID"]) && isset($_GET["quantity"])){
/****************************************************************
   Remove Exsisting Item QTY if Item Exsists in Cart, if value is zero clear item
*****************************************************************/
           if (isset($_SESSION['cartEpub'][$_GET["itemID"]])){
           
	           /*****************************************************************************
                 if current QTY greater than zero remove, if resulting QTY < or = 0 clear item
                 ******************************************************************************/
                 if ($_SESSION['cartEpub'][$_GET["itemID"]] >'0'){
                 
                      $_SESSION['cartEpub'][$_GET["itemID"]] = $_SESSION['cartEpub'][$_GET["itemID"]]-$_GET["quantity"] ;
                              /************************************
                               if resulting QTY 0 or less clear item
                              *************************************/
	                            if ($_SESSION['cartEpub'][$_GET['itemID']] <= '0'){
                              $clearRunStats = $this->clearone(); 
	                            $removeRunStats['miscError'] = $clearRunStats['errorList']; 
                              $removeRunStats['errorList'][] = 'Item Quantity is Zero, Item has been cleared';
                              }
                      $removeRunStats['updateSuccessful'] = 'true';
                 }else{
                 /**************************************************************
                 Do Not Remove There is Zero or Less QTY, Clear Item from cart
                 ***************************************************************/
                 $clearRunStats = $this->clearone();
        /********************************************************************************************
        You should never enter this else statement unless an alternate remove method has been used.
	      Absolutely don't want a negative qty ultimately creating a negative dollar amount toward total
        ***********************************************************************************************/
        $removeRunStats['errorList'][] = 'Update Action Remove Failed. Can\'t remove from a zero value. Item is now cleared.';
	      $removeRunStats['miscError'] = $clearRunStats['errorList']; 
                      $removeRunStats['updateSuccessful'] = 'false'; }
     }
/****************************************************************
	Item Requested for removal does not exsist write error
*****************************************************************/
    else{ 

	    $removeRunStats['errorList'][] = 'Update Action Remove Failed. Item requested to remove not in cart.';
	    $removeRunStats['updateSuccessful'] = 'false';
                  }
}else{  
/****************************************************************
	Required url parrams not defined, write error
*****************************************************************/
	        if(!isset($_GET['itemID'])){
	        $removeRunStats['errorList'][] = 'Update Action Remove Failed. itemId or quantity not defined'; 
          }             
	        /*if (!isset($_GET['quantity']){
	        $removeRunStats['errorList'][] = 'Update Action Remove Failed. quantity not defined.';
	        }*/
	        $removeRunStats['updateSuccessful'] = 'false';
     }
}
catch(Exception $e)
{
/****************************************************************
	other errors
*****************************************************************/
$removeRunStats['errorList'][] = $e->getMessage();
}
return $removeRunStats;
}

private function clearone(){
/****************************************************
see if there is an entry for the item, if there is an entry, clear that 
item completely from the cart, Else log error and return unsuccessful
*****************************************************/
$errorList[0] = "";
$clearoneRunStats['updateSuccessful'] = 'false';
$clearoneRunStats['display'] = '<center><strong>Please Contact Administrator</strong></center>';
$clearoneRunStats['errorList'] = $errorList;
if (isset($_GET["itemID"])){
           if (isset($_SESSION['cartEpub'][$_GET["itemID"]])){
	             //echo $_SESSION['cartEpub'[$_GET["itemID"]].'<br/>';
	             
	              unset($_SESSION['cartEpub'][$_GET["itemID"]]);
                $clearoneRunStats['updateSuccessful'] = 'true';
            }else{ 

	    $clearoneRunStats['errorList'][] = 'Update Action Clear One Failed. Item requested to clear not in cart.';
	    $clearoneRunStats['updateSuccessful'] = 'false';
                  }
}else{  
	    if (!isset($_GET["itemID"])){
	    $clearoneRunStats['errorList'][] = 'Update Action Clear Failed. itemId not defined'; 
                    }

	    $clearoneRunStats['updateSuccessful'] = 'false';
        }
return $clearoneRunStats;
}

private function clearall(){
/****************************************************
destroy session clearing everything from the cart, 
Else log error and return unsuccessful
*****************************************************/
$errorList[0] = "";
$clearallRunStats['updateSuccessful'] = 'false';
$clearallRunStats['display'] = '<center><strong>Please Contact Administrator</strong></center>';
$clearallRunStats['errorList'] = $errorList;
           if (isset($_SESSION['cartEpub'])){
	             //echo $_SESSION['cartEpub'[$_GET["itemID"]].'<br/>';
	             
	              unset($_SESSION['cartEpub']);
                $clearallRunStats['updateSuccessful'] = 'true';
            }else{ 

	    $clearallRunStats['errorList'][] = 'Cart is already clear';
	    $clearallRunStats['updateSuccessful'] = 'true';
                  }

return $clearallRunStats;
}
private function createDisplay($runStats){

$displayString = '<center><strong>Please Contact Administrator</strong></center>'; 
if(isset($runStats['updateSuccessful']) && isset($runStats['errorList'])){
 if($runStats['updateSuccessful'] == 'true'){
 //echo 'updateSuccessful is true; createDisplay';
	if ($this->updateType == 'add'){
  //echo 'update type is add; createDisplay';
	

	$displayString = '<p>A09_DictCart/updateCart.php</p><center>';
	foreach($runStats['errorList'] as $key => $value){
	$displayString = $displayString.$value.'<br/>';
     }   
      	
	if(isset($runStats['miscError'])){
	foreach($runStats['miscError'] as $key => $value){
	$displayString = $displayString.$value.'<br/>';
	}
	}
	$displayString = $displayString .'<p>'.
	$_GET["quantity"].' of item  #'. $_GET["itemID"].
	' has been successfuly added to your cart.</p><BR><BR><p>
	<a href="viewCart.php">View Cart</a></p><p>
	<a href="catalog.php">Back to Catalog</a></p></center>';
	}

	elseif ($this->updateType == 'remove'){
	

	$displayString  = '<p>A09_DictCart/updateCart.php</p><center>';
	foreach($runStats['errorList'] as $key => $value){
	$displayString = $displayString.$value.'<br/>';
	}
	if(isset($runStats['miscError'])){
	foreach($runStats['miscError'] as $key => $value){
	$displayString = $displayString.$value.'<br/>';
	}
      	}
	
	$displayString = $displayString.'<p>'.
	$_GET["quantity"].' of item  #'. $_GET["itemID"].
	' has been successfuly removed from your cart.</p><BR><BR><p>
	<a href="viewCart.php">View Cart</a></p><p>
	<a href="catalog.php">Back to Catalog</a></p></center>';
	}

	elseif ($this->updateType == 'clearone'){
	

	$displayString = '<p>A09_DictCart/updateCart.php</p><center>';
	foreach($runStats['errorList'] as $key => $value){
	$displayString = $displayString.$value.'<br/>';
        
      	}
	if(isset($runStats['miscError'])){
	foreach($runStats['miscError'] as $key => $value){
	$displayString = $displayString.$value.'<br/>';
	}
      	}
	$displayString = $displayString.'<p>
	Item  #'. $_GET["itemID"].
	' and quantity have been successfuly cleared from your cart.</p><BR><BR><p>
	<a href="viewCart.php">View Cart</a></p><p>
	<a href="catalog.php">Back to Catalog</a></p></center>';
	}

	elseif ($this->updateType == 'clearall'){
	

	$displayString = '<p>A09_DictCart/updateCart.php</p><center>';
	foreach($runStats['errorList'] as $key => $value){
	$displayString = $displayString.$value.'<br/>';
        
      	}
	if(isset($runStats['miscError'])){
	foreach($runStats['miscError'] as $key => $value){
	$displayString = $displayString.$value.'<br/>';
	}
      	}
	$displayString = $displayString.'<p>
	All Items and quantity have been successfuly cleared from your cart.</p><BR><BR><p>
	<a href="viewCart.php">View Cart</a></p><p>
	<a href="catalog.php">Back to Catalog</a></p></center>';
	}

	elseif ($this->updateType == 'not defined'){
	

	$displayString = '<p>A09_DictCart/updateCart.php</p><center>';
	foreach($runStats['errorList'] as $key => $value){
	$displayString = $displayString.$value.'<br/>';
        
      	}
	if(isset($runStats['miscError'])){
	foreach($runStats['miscError'] as $key => $value){
	$displayString = $displayString . $value . '<br/>';
	}
      	}
	$displayString = $displayString . '<p>
	There hasnt been any action taken. You should never see this when an update has been successful.</p><BR><BR><p>
	<a href="viewCart.php">View Cart</a></p><p>
	<a href="catalog.php">Back to Catalog</a></p></center>';
	}

	elseif ($this->updateType == 'invalid'){
	

	$displayString = '<p>A09_DictCart/updateCart.php</p><center>';
	foreach($runStats['errorList'] as $key => $value){
	$displayString = $displayString.$value.'<br/>';
        
      	}
	if(isset($runStats['miscError'])){
	foreach($runStats['miscError'] as $key => $value){
	$displayString = $displayString.$value.'<br/>';
	}
      	}
	$displayString = $displayString.'<p>.
	There hasnt been any action taken. You should never see this when an update has been successful </p><BR><BR><p>
	<a href="viewCart.php">View Cart</a></p><p>
	<a href="catalog.php">Back to Catalog</a></p></center>';
	}
	else{

	$displayString = '<p>A09_DictCart/updateCart.php</p><center>';
	foreach($runStats['errorList'] as $key => $value){
	$displayString = $displayString.$value.'<br/>';
        
      	}
	if(isset($runStats['miscError'])){
	foreach($runStats['miscError'] as $key => $value){
	$displayString = $displayString.$value.'<br/>';
	}
      	}
	$displayString = $displayString.'<p>.
	There hasnt been any action taken. You should never see this when an update has been successful </p><BR><BR><p>
	<a href="viewCart.php">View Cart</a></p><p>
	<a href="catalog.php">Back to Catalog</a></p></center>';
	}

}
elseif($runStats['updateSuccessful'] == 'false'){
	if ($this->updateType == 'add'){
	

	$displayString = '<p>A09_DictCart/updateCart.php</p><center>';
	foreach($runStats['errorList'] as $key => $value){
	$displayString = $displayString.$value.'<br/>';
        
      	}
	if(isset($runStats['miscError'])){
	foreach($runStats['miscError'] as $key => $value){
	$displayString = $displayString.$value.'<br/>';
	}
      	}
	$displayString = $displayString.'<p>
	The item has NOT been successfuly added to your cart.</p><BR><BR><p>
	<a href="viewCart.php">View Cart</a></p><p>
	<a href="catalog.php">Back to Catalog</a></p></center>';
	}

	elseif ($this->updateType == 'remove'){
	

	$displayString = '<p>A09_DictCart/updateCart.php</p><center>';
	foreach($runStats['errorList'] as $key => $value){
	$displayString = $displayString.$value.'<br/>';
        
      	}
	if(isset($runStats['miscError'])){
	foreach($runStats['miscError'] as $key => $value){
	$displayString = $displayString.$value.'<br/>';
	}
      	}
	$displayString = $displayString.'<p>
	The item has NOT been successfuly removed from your cart.</p><BR><BR><p>
	<a href="viewCart.php">View Cart</a></p><p>
	<a href="catalog.php">Back to Catalog</a></p></center>';
	}

	elseif ($this->updateType == 'clearone'){
	

	$displayString = '<p>A09_DictCart/updateCart.php</p><center>';
	foreach($runStats['errorList'] as $key => $value){
	$displayString = $displayString.$value.'<br/>';
        
      	}
	if(isset($runStats['miscError'])){
	foreach($runStats['miscError'] as $key => $value){
	$displayString = $displayString.$value.'<br/>';
	}
      	}
	$displayString = $displayString.'<p>
	The item and quantity have NOT been successfuly cleared from your cart.</p><BR><BR><p>
	<a href="viewCart.php">View Cart</a></p><p>
	<a href="catalog.php">Back to Catalog</a></p></center>';
	}

	elseif ($this->updateType == 'clearall'){
	

	$displayString = '<p>A09_DictCart/updateCart.php</p><center>';
	foreach($runStats['errorList'] as $key => $value){
	$displayString = $displayString.$value.'<br/>';
        
      	}
	if(isset($runStats['miscError'])){
	foreach($runStats['miscError'] as $key => $value){
	$displayString = $displayString.$value.'<br/>';
	}
      	}
	$displayString = $displayString.'<p>.
	All Items and quantity have  NOT been successfuly cleared from your cart.</p><BR><BR><p>
	<a href="viewCart.php">View Cart</a></p><p>
	<a href="catalog.php">Back to Catalog</a></p></center>';
	}


	elseif ($this->updateType == 'not defined'){
	

	$displayString = '<p>A09_DictCart/updateCart.php</p><center>';
	foreach($runStats['errorList'] as $key => $value){
	$displayString = $displayString.$value.'<br/>';
        
      	}
	if(isset($runStats['miscError'])){
	foreach($runStats['miscError'] as $key => $value){
	$displayString = $displayString.$value.'<br/>';
	}
      	}
	$displayString = $displayString.'<p>
	Update Was Not Successful</p><BR><BR><p>
	<a href="viewCart.php">View Cart</a></p><p>
	<a href="catalog.php">Back to Catalog</a></p></center>';
	}
	
	elseif ($this->updateType == 'invalid'){
	

	$displayString = '<p>A09_DictCart/updateCart.php</p><center>';
	foreach($runStats['errorList'] as $key => $value){
	$displayString = $displayString.$value.'<br/>';
        
      	}
	if(isset($runStats['miscError'])){
	foreach($runStats['miscError'] as $key => $value){
	$displayString = $displayString.$value.'<br/>';
	}
      	}
	$displayString = $displayString.'<p>
	Update Was Not Successful </p><BR><BR><p>
	<a href="viewCart.php">View Cart</a></p><p>
	<a href="catalog.php">Back to Catalog</a></p></center>';
	}
	else{

	$displayString = '<p>A09_DictCart/updateCart.php</p><center>';
	foreach($runStats['errorList'] as $key => $value){
	$displayString = $displayString.$value.'<br/>';
        
      	}
	if(isset($runStats['miscError'])){
	foreach($runStats['miscError'] as $key => $value){
	$displayString = $displayString.$value.'<br/>';
	}
      	}
	$displayString = $displayString.'<p>.
	There hasnt been any action taken. You should never see this when an update has been successful </p><BR><BR><p>
	<a href="viewCart.php">View Cart</a></p><p>
	<a href="catalog.php">Back to Catalog</a></p></center>';
	}
}
else{

$displayString = '<p>A09_DictCart/updateCart.php</p><center>';
	foreach($runStats['errorList'] as $key => $value){
	$displayString = $displayString.$value.'<br/>';
        
      	}
	if(isset($runStats['miscError'])){
	foreach($runStats['miscError'] as $key => $value){
	$displayString = $displayString.$value.'<br/>';
	}
      	}
	$displayString = $displayString.'<p>.
	There hasnt been any action taken. You should never see this when an update has been successful </p><BR><BR><p>
	<a href="viewCart.php">View Cart</a></p><p>
	<a href="catalog.php">Back to Catalog</a></p></center>';
}
$runStats['display'] = $displayString;
return $runStats;
}}//END PROCESS DISPLAY
public function processUpdate(){




$errorList[0] = "";
$displayString = '<center><strong>Please Contact Administrator</strong></center>';
$updateRunStats['updateSuccessful'] = 'false';
$updateRunStats['display'] = $displayString;
$updateRunStats['errorList'] = $errorList;

if(isset($_GET["action"])){

switch($_GET["action"]){
        case 'add':
   /******************************************************************* 
	 Run add function, if non-successful createDisplay() will instruct user of problem.
	 addItem() Returns an array with 2 keys, updateSuccessful, errorList and a 
                 possible 3rd key miscError. updateSuccessful is a string value of 'true' or 'false',
	 errorList is an array with default index 0 through end, miscError is an array with 
	 default index 0 through end. Reference updateSuccessful like this; updateRunStats-
	 ['updateSuccessful'], Reference errorList like this; updateRunStats['errorList'][$key],
	 Reference miscError like this; updateRunStats['miscError'][$key].
	*******************************************************************/
	
	$this->updateType = 'add';
                
                $updateRunStats = $this->addItem();
                //print_r($updateRunStats);
	$updateRunStats = $this->createDisplay($updateRunStats);
             break; 

        case 'remove':
	 /******************************************************************* 
	 Run remove function, if non-successful createDisplay() will instruct user of problem.
	 *******************************************************************/
	$this->updateType = 'remove';
                $updateRunStats = $this->removeItem();
	$updateRunStats = $this->createDisplay($updateRunStats);
             break; 
         break;

        case 'clearone':
	 /******************************************************************* 
	 Run clearone function, if non-successful createDisplay() will instruct user of problem.
	 *******************************************************************/
	$this->updateType = 'clearone';
	$updateRunStats = $this->clearone();
	$updateRunStats = $this->createDisplay($updateRunStats);
        break; 

        case 'clearall':
	 /******************************************************************* 
	 Run clearall function, if non-successful createDisplay() will instruct user of problem.
	 *******************************************************************/
	$this->updateType = 'clearall';
	$updateRunStats = $this->clearall();
	$updateRunStats = $this->createDisplay($updateRunStats);
        break; 
	
	

         default:
	$this->updateType = 'invalid';
	$updateRunStats['errorList'][] = 'Invalid Update Action. Please use add, remove, clearone or clearall';
	$updateRunStats = $this->createDisplay($updateRunStats);
         break; 
            
}
}else{	
$this->updateType = 'not defined';
$updateRunStats['errorList'][] = 'Update Action Not Defined. Please define action with values add, remove, clearone or clearall';
	$updateRunStats = $this->createDisplay($updateRunStats);
}

return $updateRunStats;
}//END PROCESS UPDATE
}//END CLASS CART



?>
        </div>
<!-- This layout within main row is 2 sized cells (left and right) with sized bottom banner that is not absolute-->
<div class="clear_both" style="clear:both;"></div>
        <div id="bottom_row">
          where ami
        </div>

        <div class="clear_both" style="clear:both;"></div>
      </div>




    </body>
</html>






