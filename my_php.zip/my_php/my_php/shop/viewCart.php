
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-US">

<head>
	<style type="text/css" media="screen">
		@import url(../style.css);
	</style>
<?php session_start(); ?>
</head>

<body>

<div id="page_container" class="aligncenter">
<div id="top_row">
<div id='head_row_one'>
<?php 
include 'dbOps.php';
$dbObj = new itemsDbAdapter;
include '../includes/user_menu.php'
?>
</div>

<div id="clear_both" style="clear:both;"></div>


<div id="menu" class="right">
<ul class="top_nav">
<li><a href="../portfolio/cover.php">Portfolio</a></li>
<li><a href="../projects/project_listing.php">Projects</a></li>
<li><a href="../contact/contact.php">Contact Me</a></li>
<li><a href="../code/overview.php">Example Code</a></li>
<li><a href="../shop/catalog.php">My Shop</a></li>
</ul>

</div>
<div id="clear_both" style="clear:both;"></div>
</div>
<div id="clear_both" style="clear:both;"></div>
<div id="main_row">
<div id="left_container">
<!--<img src="chair_tilt.gif" class"alignleft" id="left_chair_one"/>-->
</div>
<div id="right_container">

<center>

<h2>Shopping Cart Contents</h2>

<table border="1">

  <tr>
    <td>Image</td>
    <td>Item Nmbr</td>
    <td>Desc</td>
    <td>Quantity</td>
    <td>cost</td>
    <td>Ops</td>
  </tr>
  
<?PHP
if(isset($_SESSION['cartEpub'])){
static $cstTtl = 0;
$cstHld = 0;
foreach($_SESSION['cartEpub'] as $key => $value){
  $cstHld = $dbObj->listSubSetByID($key,$key,
  'price');
  $cstTtl = $cstTtl + ($cstHld[0]['price']*$value); ?>
  <tr>
    <td>Image</td>
    <td><?PHP echo $key ; ?></td>
    <td>Descrip</td>
    <td><?PHP echo $value; ?></td>
    <td>
      <?PHP echo ($cstHld[0]['price']*$value); ?></td>
    <TD><a href="updateCart.php?action=remove&amp;itemID=<?PHP echo $key ; ?>&amp;quantity=1">Remove one!</a><br/>
    <br/><a href="updateCart.php?action=clearone&amp;itemID=<?PHP echo $key ; ?>&amp;quantity=1">Clear Item</a></TD>
  </tr>
<?PHP }} ?>
<tr>
  <td></td>
  <td></td>
  <td></td>
  <td>Total Price >></td>
  <td><?PHP echo $cstTtl ?></td>
  <td>
    <div class="right">
      <a href="updateCart.php?action=clearall&amp;itemID=007228&amp;quantity=1">Clear All</a>
    </div>
  </td>
</tr>
  
  
</table>

<p align="center"><a href="catalog.php">Back to Catalog</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="checkOut.php">Proceed To Check Out</a>
</p>

</center>
</div>
  <div id="clear_both" style="clear:both;"></div>
<div id="bottom_row">
where ami
</div>

<div id="clear_both" style="clear:both;"></div>
</div>




</body>
</html>

