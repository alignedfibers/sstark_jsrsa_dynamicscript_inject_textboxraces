<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-US">

<head>
	<style type="text/css" media="screen">
		@import url(../style.css);
	</style>
<?php session_start(); ?>
</head>

<body>

<div id="page_container" class="aligncenter">
  <div id="top_row" class="row">
    <div id='head_row_one'>
      <?php 

include '../includes/user_menu.php'
?>

    
    </div>

   
    <div id="clear_both" style="clear:both;"></div>
    <div id="menu" class="right">
      <ul class="top_nav">
        <li>
          <a href="../portfolio/cover.php">Portfolio</a>
        </li>
        <li>
          <a href="../projects/project_listing.php">Projects</a>
        </li>
        <li>
          <a href="../contact/contact.php">Contact Me</a>
        </li>
        <li>
          <a href="../code/overview.php">Example Code</a>
        </li>
        <li>
          <a href="../shop/catalog.php">My Shop</a>
        </li>
      </ul>

    </div>
  </div>
<div id="clear_both" style="clear:both;"></div>

 
<div id="main_row">
<div id="left_container">
<!--<img src="chair_tilt.gif" class"alignleft" id="left_chair_one"/>-->
</div>
<div id="right_container">
</div>
</div>
<div id="bottom_row">
where ami
</div>

<div id="clear_both" style="clear:both;"></div>
</div>




</body>
</html>