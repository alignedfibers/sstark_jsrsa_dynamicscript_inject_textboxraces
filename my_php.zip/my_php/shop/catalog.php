<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-US">

<head>
	<style type="text/css" media="screen">
		@import url(../style.css);
	</style>
<?php session_start(); ?>
</head>

<body>

<div id="page_container" class="aligncenter">
<div id="top_row">
<div id='head_row_one'>
<?php 

include '../includes/user_menu.php'
?>
</div>

<div id="clear_both" style="clear:both;"></div>


<div id="menu" class="right">
<ul class="top_nav">
<li><a href="../index.php">Home</a></li>
<li><a href="../shop/catalog.php">My Shop</a></li>
</ul>

</div>
<div id="clear_both" style="clear:both;"></div>
</div>
<div id="clear_both" style="clear:both;"></div>
<div id="main_row">
<div id="left_container">
<!--<img src="chair_tilt.gif" class"alignleft" id="left_chair_one"/>-->
</div>
<div id="right_container">
<div class="left">
<font size="6">Shopping Catalog</font>
      <a href="../shop/viewCart.php">
        <img src="../images/cart.gif"/>
      </a>
  <a href="../shop/catalog.php">List All</a>
</div>
          <div class="right">
          <form class="search_box" method="get" action="../shop/catalog.php">
	         Search:<input type="text" name="s" id="s" size="15" />
		<input type="submit" value="Search" />
	 </form>
	 </div>
	 <div id="clear_both" style="clear:both;"></div>
	 <?PHP if($_COOKIE['userEpub']['priv'] == 'admin'){
	 echo '<center><a href="item_form.php?itemid=">New Item</a></center><br/>';
	 } ?>
	       <TABLE border=1 cellPadding=3 cellSpacing=1 style="float:right; margin-right: 20px;">
        <TBODY>
        <TR><?PHP if($_COOKIE['userEpub']['priv'] == 'admin'){echo '<TD>Admin</TD>';} ?><TD>Image</TD><TD>ItemID</TD><TD>Description</TD><TD>Price</TD><TD>Add Item To Cart</TD></TR>

<?PHP
/****************************************
Just including the dbOps.php file and instantiating
itemsDbAdapter within it. Using the object created
I call the listAll function to get an array of the rows
returned from the method and display it.
****************************************/
//include 'userValidation.php';
include 'dbOps.php';

$dataObj = new itemsDbAdapter;
if(isset($_GET['s'])&& $_GET['s'] != ''){
$listAll = $dataObj->search($_GET['s']);      
}else{
$listAll = $dataObj->listAll(); //search('Dri lok guide "AND"');
}
if(is_array($listAll)){
foreach($listAll as $key=>$value){
echo '<TR>';
	if($_COOKIE['userEpub']['priv'] == 'admin'){
	echo '<td><a href="item_form.php?itemid='.$value['itemID'].'">Modify</a></td>';
	}
	foreach($value as $keyNest=>$valueNest){
	     if($keyNest == 'imagePath'){
	      echo '<td><IMG src="'.$valueNest.'"width="100" height="100"></td>';
                    }else{
	    echo '<td>'.$valueNest.'</td>';}
	}
echo '<TD>          <form class="addfrm" method="get" action="../shop/updateCart.php">
	         Quantity:<br/><input type="text" name="quantity" id="s" size="10" />
		<input type="submit" value="addItm" />
					 <input type="hidden" name="action" value="add"/>
			 <input type="hidden" name="itemID" value="'.$value['itemID'].'"/>
	 </form></TD></TR>';
}
}
?>
</TBODY>
    </TABLE>
      </div>
</div>
<div id="bottom_row">
where ami
</div>

<div id="clear_both" style="clear:both;"></div>
</div>




</body>
</html>