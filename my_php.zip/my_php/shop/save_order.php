<?php //Written by Shawn Stark 12.17.2008
include '../includes/conf.php';
include '../includes/dbOps.php';
session_start(); 
$caller = '';
$dataObj = new dbAdapter; 
/***********************************************************************
Debating on how to allow Administrators to add or modify orders for anyone
using this same script. I would rather not place user id as a hidden field in order 
form as it may be a security leak even though I ensure user is logged in session. 
I can add another check to ensure if user is not admin the posted userID matches
the sessionID. This will eliminate users from adding orders for anyone other than
themselves or users they dont have a password and login for, While allowing admins to
post changes for any user. Adding new orders for any user may be a challenge unless
I can load a profile into session, allowing admin to appear as that user. Doing this would
include adding another check on all pages for profile and clearing cart upon profile change.
Cart clears on logout, it should also clear upon successful save/submission of order.
**************************************************************************/
/*********************
   Check User 
  ************************/
if(isset($_COOKIE['userEpub']['un']) && isset($_COOKIE['userEpub']['status']) && isset($_COOKIE['userEpub']['priv']) ){

if($_COOKIE['userEpub']['status'] == 'logged'){	 

if(isset($_GET['action'])){

/*********************
Do Order Process based on action
    ************************/
$action = $_GET['action'];
switch($action){


case 'insert':
     if(isset($_POST['sFname']) && isset($_POST['sLname'])&& isset($_POST['sAddr'])&& isset($_POST['sCity'])&& isset($_POST['sStateCmb'])&& isset($_POST['sZip'])&& isset($_POST['sPnum'])&& isset($_POST['sCnum'])&& isset($_POST['total'])){    
     $dataObj->insertSubSet('Orders','sUserID,sFname,sLname,sAddr,sCity,sState,sZip,sTeliphone,sCell,sTotal',$_COOKIE[userEpub]['id'].','.$_POST['sFname'].','.$_POST['sLname'].','.$_POST['sAddr'].','.$_POST['sCity'].','.$_POST['sStateCmb'].','.$_POST['sZip'].','.$_POST['sPnum'].','.$_POST['sCnum'].','.$_POST['total']);

/***********************************************************************************************************
The order details will be saved in the orderItems table... The problem with doing this is getting the auto ID from the last insert
to insure reference between the two tables. I can do it with my_sql but not access. Access does not have a version of LAST_INSERT_ID(), there are techniquies using IS NULL, but I was unsuccessful using them.
***********************************************************************************************************/
?>
<html>
  <head>
    <meta http-equiv="Refresh" content="5;url=../shop/catalog.php">
    </head>
  <body>
    <div class="row">
      <div>
        Redirecting...<div>
          <div>You have successfuly added an order, This order should now be found under orders in your control panel</div>
          <div>
            if your browser does not redirect you in 5 seconds click <a href="../shop/catalog.php">here</a>
          </div>
        </div>
      </body>
</html>
<?PHP }else{ ?>
<html>
<head>
<meta http-equiv="Refresh" content="5;url=../shop/catalog.php">
</head>
<body>
<div class="row">
  <div>Redirecting...<div>
<div>Can not process order. Order is missing important information. Please try again</div>
<div>if your browser does not redirect you in 5 seconds click <a href="../shop/catalog.php">here</a></div>
</div>
</body>
</html>
<?PHP }
break;

case 'update':
     if(isset($_POST['sFname']) && isset($_POST['sLname'])&& isset($_POST['sAddr'])&& isset($_POST['sCity'])&& isset($_POST['sStateCmb'])&& isset($_POST['sZip'])&& isset($_POST['sPnum'])&& isset($_POST['sCnum'])&& isset($_POST['total'])){    
     $isUpdated = $dataObj->updateSubSet('Orders','sUserID,sFirstName,sLastName,sAddress,sCity,sState,sZip,sTeliphone,sCell,sTotal',$_COOKIE[userEpub]['id'].','.$_POST['sFname'].','.$_POST['sLname'].','.$_POST['sAddrs'].','.$_POST['sCity'].','.$_POST['sStateCmb'].','.$_POST['sZip'].','.$_POST['sPnum'].','.$_POST['sCnum']);
?>
<html>
  <head>
    <meta http-equiv="Refresh" content="5;url=../shop/catalog.php">
    </head>
  <body>
    <div class="row">
      <div>
        Redirecting...<div>
          <div>You have successfuly updated an order, The changes to this order should now be found under orders in your control panel</div>
          <div>
            if your browser does not redirect you in 5 seconds click <a href="../shop/catalog.php">here</a>
          </div>
        </div>
      </body>
</html>
<?PHP }else{ ?>
<html>
<head>
<meta http-equiv="Refresh" content="5;url=../shop/catalog.php">
</head>
<body>
<div class="row">
  <div>Redirecting...<div>
<div>Can not process order. Order is missing important information. Please try again</div>
<div>if your browser does not redirect you in 5 seconds click <a href="../shop/catalog.php">here</a></div>
</div>
</body>
</html>
<?PHP }
break;
}
}
else{?>
<html>
<head>
<meta http-equiv="Refresh" content="5;url=../index.php">
</head>
<body>
<div class="row">
<div>Redirecting...<div>
<div>No action submited</div>
<div>if your browser does not redirect you in 5 seconds click <a href="../index.php">here</a></div>
</div>
</body>
</html>
<?PHP
}}}
?>
