<?PHP
session_start();
include 'dbOps.php';
$dbObj = new itemsDbAdapter;
if(isset($_SESSION['userEpub'])&& $_SESSION['userEpub']['priv'] == 'admin'){

if(isset($_GET['action']) && $_GET['action'] != null ){
$action = $_GET['action'];
switch($action){
case delete:
echo 'entered delete';
if(isset($_GET['itemid'])){
//echo 'ID is set';
$itemid = $_GET['itemid'];
$isDeleted = $dbObj->delete($itemid);
if($isDeleted == 'true')
{ ?>
<meta  http-equiv="Refresh" content="5;url=default.php">
Redirecting....<br/>
Item Successfuly Removed
If your browser does not redirect you click <a href="default.php">here</a>

<?PHP }
else{ ?>
<meta  http-equiv="Refresh" content="5;url=default.php">
Redirecting....<br/>
Unable To Remove Item,br/>
If your browser does not redirect you click <a href="default.php">here</a>

<?PHP }

}
break;
case 'update':
	if(isset($_GET['txtDesc']) && isset($_GET['txtPrice']) && isset($_GET['txtImagePath']) && isset($_GET['itemId'] ))
	{





$isUpdated = $dbObj->updateSubSet($_GET['itemId'], $_GET['itemId'],'description,price,imagePath', $_GET['txtDesc'].','.$_GET['txtPrice'].','.$_GET['txtImagePath']);
	
	if($isUpdated == 'true')
	{ ?>
<meta  http-equiv="Refresh" content="5;url=../shop/catalog.php">
Redirecting....<br/>
Item Successfully Changed
If your browser does not redirect you click <a href="../shop/catalog.php">here</a>
<?PHP }
else{ ?>
<meta  http-equiv="Refresh" content="5;url=default.php">
Redirecting....<br/>
Unable To Remove Contact,br/>
If your browser does not redirect you click <a href="../shop/catalog.php">here</a>

<?PHP }};
break;

case 'insert':
	if(isset($_GET['txtDesc']) && isset($_GET['txtPrice']) && isset($_GET['txtImagePath']) && isset($_GET['itemId']))
	{





$isUpdated = $dbObj->insertSubSet($_GET['itemId'], $_GET['itemId'],'itemID,description,price,imagePath', $_GET['itemId'].','.$_GET['txtDesc'].','.$_GET['txtPrice'].','.$_GET['txtImagePath']);

	if($isUpdated == 'true')
	{ ?>
<meta  http-equiv="Refresh" content="5;url=../shop/catalog.php">
Redirecting....<br/>
Item Successfuly Added
If your browser does not redirect you click <a href="../shop/catalog.php">here</a>
<?PHP }
else{ ?>
<meta  http-equiv="Refresh" content="5;url=../shop/catalog.php">
Redirecting....<br/>
Unable To Add Item,br/>
If your browser does not redirect you click <a href="../shop/catalog.php">here</a>

<?PHP }}
break;
}
}
else{
echo '<center>Sorry request can not be processed, action parrameter is either undefined or ommited </center>';
}
}
else{
echo '<center> You do not have authorization to view this page <br/> if you feel you have reached this message in error<br/> please ensure you are logged in as admin</center>';
}
