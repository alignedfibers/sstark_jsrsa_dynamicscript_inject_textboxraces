<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-US">

<head>
	<style type="text/css" media="screen">
		@import url(../style.css);
	</style>
<?php session_start(); ?>
</head>

<body>

<div id="page_container" class="aligncenter">
<div id="top_row">
<div id='head_row_one'>
<?php 

include '../includes/user_menu.php'
?>
</div>

<div id="clear_both" style="clear:both;"></div>


<div id="menu" class="right">
<ul class="top_nav">
<li><a href="../portfolio/cover.php">Portfolio</a></li>
<li><a href="../projects/project_listing.php">Projects</a></li>
<li><a href="../contact/contact.php">Contact Me</a></li>
<li><a href="../code/overview.php">Example Code</a></li>
<li><a href="../shop/catalog.php">My Shop</a></li>
</ul>

</div>
<div id="clear_both" style="clear:both;"></div>
</div>
<div id="clear_both" style="clear:both;"></div>
<div id="main_row">
<div id="left_container">
<!--<img src="chair_tilt.gif" class"alignleft" id="left_chair_one"/>-->
</div>
  <div id="right_container">




    <?PHP
include 'dbOps.php';
$dbObj = new itemsDbAdapter;


if(isset($_SESSION['userEpub'])&& $_SESSION['userEpub']['priv'] == 'admin'){

if(isset($_GET['itemid']) && $_GET['itemid'] != null){
$action = update;
$strippedID = $dbObj->trimAll($_GET['itemid']);
$itemData = $dbObj->listSubSetByID($strippedID,$strippedID,
'itemID,description,price,imagePath');
display();
}
else{
$action = 'insert';
$itemData[] =  array('itemID'=>'','description'=>'','price'=>'','imagePath'=>'');
display();

}

}
else{

echo '<center> You do not have authorization to view this page <br/> if you feel you have reached this message in error<br/> please ensure you are logged in as admin</center>';

}


function display(){
global $action;
global $itemData;
//print_r($itemData);
foreach($itemData as $key=>$value){?>
    
    <TABLE border="0" cellpadding="1" cellspacing="0">
      <form method="GET" action="modifyList.php">

        <TR align="center">
          <TD colspan="4">
            <BR>
              <b>ITEM FORM</b>
              <br>
                <br>
          </TD>
        </TR>
        <TR>
          <TD>
            <FONT face="arial,helvetica" size="2">
              <b>ID</b>
            </FONT>
          </TD>
          <TD>
            <INPUT type="text" name="itemId" value="<?PHP echo $value['itemID']; ?>" size="15" >
          </TD>

        </TR>

        <TR>
          <TD align="right">
            <FONT face="arial,helvetica" size="2">
              <b>Item Description:</b>
            </FONT>
          </TD>
          <TD>
            <INPUT type="text" name="txtDesc" value="<?PHP echo $value['description']; ?>" size="65" >
          </TD>
          <TD align="right">
            <FONT face="arial,helvetica" size="2">
              <b>Price</b>
            </FONT>
          </TD>
          <TD>
            <INPUT type="text" name="txtPrice" value="<?PHP echo $value['price']; ?>" size="4" maxlength="8">
          </TD>
        </TR>

        <TR>
          <TD align="right">
            <FONT face="arial,helvetica" size="2">
              <b>Image Path</b>
            </FONT>
          </TD>

          <TD>
            <INPUT type="text" name="txtImagePath" value="<?PHP echo $value['imagePath']; ?>" size="65" >
          </TD>
        </TR>



      </TABLE>

    <br>

      <input type="submit" value="Save" name="btnSave">

        <input type="hidden" name="action" value="<?PHP echo $action; ?>">


          </form>
          </table>
        
        <div class="clear_both" style="clear:both;"></div>
  
<?PHP }} ?>



</div>
  <div id="clear_both" style="clear:both;"></div>
<div id="bottom_row">
where ami
</div>

<div id="clear_both" style="clear:both;"></div>
</div>




</body>
</html>