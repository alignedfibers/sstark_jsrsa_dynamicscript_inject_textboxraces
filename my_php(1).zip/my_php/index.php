<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-US">

<head>
	<style type="text/css" media="screen">
		@import url(style.css);
	</style>
<?php session_start(); ?>
</head>

<body>

<div id="page_container" class="aligncenter">
<div id="top_row">
  <div id='head_row_one'>
    <?php 

if(isset($_SESSION['userEpub']['un']) && isset($_SESSION['userEpub']['status']) && isset($_SESSION['userEpub']['priv']) ){

if($_SESSION['userEpub']['status'] == 'logged'){	 ?>
<div class="opsPanel">
  <ul>
    <li>
<?PHP
if($_SESSION['userEpub']['priv'] == 'admin'){?>
<a href="admin_tools/cp.php">
<?PHP }else{ ?>
    <a href="user_tools/cp.php">
<?PHP } ?>
        <img src="images/cp_icon.gif"/>
      </a>
    </li>
    <li>
      <a href="shop/viewCart.php">
        <img src="images/cart.gif"/>
      </a>
    </li>
  </ul>
  
</div>
    <div class="right" width="218">
  <div class="right" width="218">

    <div class="row">
      Welcome &nbsp; <?PHP echo $_SESSION['userEpub']['un'].'.'; ?>
    </div>
    <div class="row">
      You are logged in.
    </div>
    <div class="row">
      <a href="login_tools/log_tool.php?action=logout">Logout
      
      </a>
    </div>
  </div>
    </div>
      <?PHP }
elseif($_SESSION['userEpub']['status'] == 'notlogged'){ ?>
      <div class="row right" width="218">
        <form id="login_form" name="login_form" action="login_tools/log_tool.php?action=login" method="post">
          User Login

          <input size="15" name="user_name" id="user_name" class="search_fields" />

          <input size="15" type="password" name="password" id="password"  class="search_fields" />

          <a href="login_tools/register.php">Register</a>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <input name="submit" type="submit" value="Login" style="border:1px solid #999999; background-color:#CCCCCC; font-size:10px"/>

        </form>
      </div>
      <?PHP
}
}
else{
$_SESSION['userEpub']['un']= 'guest'; 
$_SESSION['userEpub']['status']= 'notlogged'; 
$_SESSION['userEpub']['priv']= 'guest';?>
      <div class="right" width="218">
        <form id="login_form" name="login_form" action="login_tools/log_tool.php?action=login" method="post">
          User Login
          <input size="15" name="user_name" id="user_name" class="search_fields" />

          <input size="15" type="password" name="password" id="password"  class="search_fields" />

          <a href="login_tools/register.php" >Register</a>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <input name="submit" type="submit" value="Login" style="border:1px solid #999999; background-color:#CCCCCC; font-size:10px"/>

        </form>
      </div>
      <?PHP

}
?>
    </div>

    <div id="clear_both" style="clear:both;"></div>

<div id="menu" class="right">
<ul class="top_nav">
<li><a href="portfolio/cover.php">Portfolio</a></li>
<li><a href="projects/project_listing.php">Projects</a></li>
<li><a href="contact/contact.php">Contact Me</a></li>
<li><a href="code/overview.php">Example Code</a></li>
<li><a href="shop/catalog.php">My Shop</a></li>
</ul>

</div>
<div id="clear_both" style="clear:both;"></div>
</div>
<div id="clear_both" style="clear:both;"></div>
<div id="main_row">
<div id="left_container">

</div>
<div id="right_container">
</div>
</div>
<div id="bottom_row">
where ami
</div>

<div id="clear_both" style="clear:both;"></div>
</div>




</body>
</html>