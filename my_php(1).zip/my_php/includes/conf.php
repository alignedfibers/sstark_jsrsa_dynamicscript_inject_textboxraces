<?PHP
/********************************************
Please change the value of the fileLoc variable to the 
location of the catalog access database on your machine
**********************************************/
$fileLoc = 'C:\data\php_shawn.mdb';
?>